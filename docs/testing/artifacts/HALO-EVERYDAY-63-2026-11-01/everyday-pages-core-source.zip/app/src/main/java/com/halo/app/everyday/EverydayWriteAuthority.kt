package com.halo.app.everyday

import kotlinx.coroutines.asContextElement
import kotlinx.coroutines.withContext

/** An explicit UI/tool action carries revocable authority through suspension into its durable owner. */
object EverydayWriteAuthority {
    private val current = ThreadLocal<(() -> Unit)?>()
    suspend fun <T> run(check: () -> Unit, action: suspend () -> T): T {
        check()
        return withContext(current.asContextElement(check)) { action() }
    }
    /** Background owners retain their existing independent policy; only scoped actions carry this lease. */
    fun requireCurrent() { current.get()?.invoke() }
}
