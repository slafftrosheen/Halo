@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)

package com.halo.app.ui.shell

import com.halo.app.ui.presence.invokePageAction

import com.halo.app.language.uiText
import com.halo.app.ui.everyday.*

import androidx.lifecycle.compose.collectAsStateWithLifecycle

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTagsAsResourceId
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Scaffold
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import com.halo.app.ui.theme.rememberReducedMotion
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import kotlinx.coroutines.launch

import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import androidx.lifecycle.viewmodel.compose.viewModel
import com.halo.app.di.ManualDependencyGraph
import com.halo.app.ai.readRuntimeAiContextPolicy
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.halo.app.data.notebook.WorkspaceObjectType
import com.halo.app.ui.icons.HaloGlyph
import com.halo.app.ui.screens.activity.ActivityScreen
import com.halo.app.ui.screens.devices.BuddyBotControlScreen
import com.halo.app.ui.screens.devices.DevicesScreen
import com.halo.app.ui.screens.devices.HeyCyanControlScreen
import com.halo.app.ui.screens.discovery.PairingScreen
import com.halo.app.ui.screens.home.HomeScreen
import com.halo.app.ui.screens.notebook.ConversationDetailScreen
import com.halo.app.ui.screens.notebook.ConversationsListScreen
import com.halo.app.ui.screens.notebook.CanvasEditorScreen
import com.halo.app.ui.screens.notebook.CanvasEditorViewModel
import com.halo.app.ui.screens.notebook.NoteEditorScreen
import com.halo.app.ui.screens.notebook.NoteEditorViewModel
import com.halo.app.ui.screens.study.StudyScreen
import com.halo.app.ui.screens.study.StudyViewModel
import com.halo.app.ui.screens.notebook.NotebookNavigation
import com.halo.app.ui.screens.notebook.NotebookScreen
import com.halo.app.ui.screens.notebook.WorkspaceObjectDetailScreen
import com.halo.app.ui.screens.settings.AndroidAssistantScreen
import com.halo.app.ui.screens.settings.IntelligenceScreen
import com.halo.app.ui.screens.settings.RuntimeScreen
import com.halo.app.ui.screens.settings.SettingsScreen
import com.halo.app.ui.screens.settings.SkillsScreen
import com.halo.app.ui.screens.settings.VoiceSettingsScreen
import com.halo.app.ui.screens.settings.StorageBackupScreen
import com.halo.app.ui.screens.settings.SystemCheckScreen
import com.halo.app.ui.screens.settings.SystemCheckViewModel
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String, val glyph: HaloGlyph) {
    data object Home : Screen("home", "Home", HaloGlyph.HOME)
    data object Study : Screen("study", "Study", HaloGlyph.QUESTION)
    data object Activity : Screen("activity", "Activity", HaloGlyph.ACTIVITY)
    data object Notebook : Screen("notebook", "Workspace", HaloGlyph.NOTE)
    data object Devices : Screen("devices", "Devices", HaloGlyph.DEVICE)
    data object Settings : Screen("settings", "Settings", HaloGlyph.SETTINGS)
}

val bottomNavItems = listOf(Screen.Home, Screen.Notebook, Screen.Devices, Screen.Settings)

@Composable
fun AppShell(
    onRequestPermissions: () -> Unit,
    onRequestBluetoothPermissions: () -> Unit,
    onRequestBluetoothEnable: () -> Unit,
    onRequestSkillPermissions: (Set<com.halo.sdk.runtime.skills.HostPermission>, Set<String>) -> Unit = { _, _ -> },
    onCompactChanged: (Boolean) -> Unit = {},
) {
    val navController = rememberNavController()
    var screenMode by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    var screenFull by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    val reducedMotion by rememberReducedMotion()
    val setupStore = ManualDependencyGraph.setupProgress
    // Only the first un-dismissed launch opens setup. "Save and leave" is durable
    // across Activity recreation/process death even when all checks remain incomplete.
    val initialSetupNeeded = remember { setupStore.shouldAutoLaunch() }
    var setupSession by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(initialSetupNeeded) }
    val homeViewModel = ManualDependencyGraph.homeViewModel
    // Activity foreground owns voice; route disposal must not end a global session.
    val shellLifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    val shellActivity = com.halo.app.ui.mini.miniHaloActivityOwner(LocalContext.current)
    androidx.compose.runtime.DisposableEffect(shellLifecycle, homeViewModel, shellActivity) {
        val binding = bindShellSpeechLifecycle(shellLifecycle, {
            val host = shellActivity as? com.halo.app.MainActivity
            if (host != null) host.speechHandoff.preservesSpeechOnStop(host.isChangingConfigurations, host.isFinishing)
            else shellActivity?.isChangingConfigurations == true
        }) {
            homeViewModel.onHomeStopped()
            homeViewModel.cancelVoiceInput()
        }
        onDispose { binding.close() }
    }
    val kidsMode by ManualDependencyGraph.kidsPreferences.enabled.collectAsStateWithLifecycle()
    val kidsReady by ManualDependencyGraph.kidsPreferences.loadedState.collectAsStateWithLifecycle()
    val kidsLoadError by ManualDependencyGraph.kidsPreferences.loadError.collectAsStateWithLifecycle()
    if (!kidsReady) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(uiText("Starting halo…")) }
        return
    }
    LaunchedEffect(kidsMode) { if (kidsMode) navController.navigateToPrimary("home") }
    val shellScope = rememberCoroutineScope()
    val studyContext = LocalContext.current
    val exportOwner = ManualDependencyGraph.workspaceExternalExport
    com.halo.app.ui.workspace.WorkspaceExternalExportHost(exportOwner, permitted = !kidsMode)

    /*
     * RUNTIME-019: the global interaction renderer lives OUTSIDE screen
     * navigation, so a pending durable request stays resolvable from any tab
     * (spec #68). The ViewModel owns presentation state; composables never
     * read the dependency graph directly (spec #83). Dismiss only hides the
     * surface — the durable request remains pending (spec #65).
     */
    val interactionViewModel: com.halo.app.interaction.InteractionSurfaceViewModel =
        androidx.lifecycle.viewmodel.compose.viewModel(
            factory = com.halo.app.interaction.InteractionSurfaceViewModelFactory(),
        )
    val interactionState by interactionViewModel.state.collectAsStateWithLifecycle()
    interactionState.primary?.let { surface ->
        ShellInteractionSurface(
            surface = surface,
            onRespond = interactionViewModel::respond,
        )
    }

    var parentRoute by remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var parentUnavailable by remember { androidx.compose.runtime.mutableStateOf(false) }
    var settingsRootRequest by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(0L) }
    var workspaceRootRequest by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(0L) }
    fun performNavigation(requested: String) {
        val route = if (ManualDependencyGraph.kidsPreferences.enabled.value && requested == "mini_halo") "home" else requested
        if (com.halo.app.ui.screens.settings.isDeveloperDestination(route) &&
            !ManualDependencyGraph.storage.getBoolean("halo_developer_tools_enabled", false)) {
            if (navController.currentDestination?.route != "advanced_settings")
                navController.navigate("advanced_settings") { launchSingleTop = true }
            return
        }
        val activity = com.halo.app.ui.mini.miniHaloActivityOwner(studyContext)
        if (activity is com.halo.app.ui.mini.MiniHaloActivity && route != "mini_halo" && route in HaloScreenCatalog.screens) {
            activity.openFullHaloFromMini(route)
            return
        }
        if (route == "screen") {
            screenMode = true
            screenFull = false
            navController.navigateToPrimary("home", restoreSavedState = false)
            return
        }
        if (route == "home") { screenMode = false; screenFull = false }
        val currentBell = navController.currentDestination?.route
        if (route in setOf("activity", "notifications") &&
            (currentBell?.startsWith("activity") == true || currentBell == "notifications")) {
            if (currentBell.substringBefore("?") != route) navController.navigate(route) {
                popUpTo(navController.currentDestination!!.id) { inclusive = true; saveState = true }
                launchSingleTop = true
                restoreState = true
            }
            return
        }
        // Explicit root requests reset presentation even when the route itself has not changed.
        // Back/deep-link restoration does not issue this signal or clear domain state.
        if (route == "settings") settingsRootRequest++
        if (route == "notebook") workspaceRootRequest++
        if (navController.currentDestination?.route != route) {
            if (route == "guided_setup") { navController.navigateToGuidedSetup(); return }
            if (bottomNavItems.any { it.route == route }) navController.navigateToPrimary(route, restoreSavedState = false)
            else navController.navigateToInstrument(route)
        }
    }
    val parentGate = com.halo.app.ui.screens.kids.rememberKidsGrownUpGate(
        onVerified = { parentRoute?.let(::performNavigation); parentRoute = null },
        onUnavailable = { parentRoute = null; parentUnavailable = true })
    fun navigateSafely(route: String) {
        val childSurface = route in setOf("home", "mini_halo", "study", "workspace_handoff") ||
            route.substringBefore("?") in setOf(EverydayRoutes.BRIEF, EverydayRoutes.CLOCKS, EverydayRoutes.ORGANIZER, EverydayRoutes.SOURCE) ||
            route.startsWith("notebook/note/") || route.startsWith("notebook/canvas/") || route.startsWith("notebook/study/")
        if (ManualDependencyGraph.kidsPreferences.enabled.value && !childSurface) { parentRoute = route; parentGate() }
        else performNavigation(route)
    }
    suspend fun openWorkspaceFile(id: String) {
        val route = try {
            val item = ManualDependencyGraph.workspaceContinuity.describe(id)
            ManualDependencyGraph.workspaceContinuity.route(id, item.version, com.halo.app.data.workspace.WorkspaceDestination.OPEN)
        } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
        catch (_: Exception) { "notebook/file/${android.net.Uri.encode(id)}" }
        navigateSafely(route)
    }
    val requestVoiceModeFromSurface: () -> Unit = {
        val current = homeViewModel.uiState.value
        when {
            !current.microphonePermissionGranted -> {
                homeViewModel.requestVoiceModeStart()
                navController.navigateToPrimary("home")
            }
            !current.speechReady -> navigateSafely("voice_settings")
            else -> {
                homeViewModel.requestVoiceModeStart()
                navController.navigateToPrimary("home")
            }
        }
    }
    if (parentUnavailable) androidx.compose.material3.AlertDialog(onDismissRequest = { parentUnavailable = false },
        title = { Text(uiText("Grown-up space")) },
        text = { Text(uiText("Ask a grown-up to set a device PIN or password in Android settings first.")) },
        confirmButton = { TextButton(onClick = { parentUnavailable = false }) { Text(uiText("OK")) } })
    val ownerLifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    val navigateRequestedScreen by rememberUpdatedState(newValue = ::navigateSafely)
    LaunchedEffect(ownerLifecycle) {
        HaloScreenRequests.collectResumed(ownerLifecycle, ManualDependencyGraph.requestedHaloScreen) {
            navigateRequestedScreen(it)
        }
    }
    LaunchedEffect(Unit) {
        val screen = ManualDependencyGraph.assistantPreferences.get().startScreen
        val kids = ManualDependencyGraph.kidsPreferences.getEnabled()
        if (!kids && !ManualDependencyGraph.explicitHaloScreenRequested && ManualDependencyGraph.requestedHaloScreen.value == null && navController.currentDestination?.route == "home" && screen != "home") navigateSafely(screen)
    }

    LaunchedEffect(homeViewModel) {
        homeViewModel.navigationEvents.collectLatest(::navigateSafely)
    }
    LaunchedEffect(Unit) {
        val graph = ManualDependencyGraph
        graph.interactionContext.navigation.collectLatest { target ->
            try { when(target) {
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.FollowUp -> {
                    if(graph.conversationStore.activeConversationId() == target.conversationId) {
                        check(target.turnId == null || graph.conversationStore.turnsForConversation(target.conversationId).any { it.id == target.turnId }) { "Reply unavailable" }
                        navigateSafely("home"); homeViewModel.composerFocus.value += 1
                    }
                }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.OpenStudy -> {
                    check(graph.workspaceContext.versionFor(target.sourceId) != null) { "Source unavailable" }
                    navigateSafely("study?captureSource=${android.net.Uri.encode(target.sourceId)}")
                }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.OpenSource -> {
                    val source = graph.workspaceContinuity.describe(target.objectId)
                    navigateSafely(graph.workspaceContinuity.route(source.objectId, source.version, com.halo.app.data.workspace.WorkspaceDestination.OPEN))
                }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.ContinueStudy -> {
                    check(graph.studyUseCases.getSession(target.sessionId)?.lifecycle == com.halo.sdk.runtime.study.StudySessionLifecycle.ACTIVE) { "Study session unavailable" }
                    navigateSafely("notebook/study/${android.net.Uri.encode(target.sessionId)}")
                }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.ReviewMemory -> {
                    check(graph.workspaceContext.versionFor(target.sourceId) != null) { "Source unavailable" }
                    navigateSafely("notebook/memory?section=Memories")
                }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.ReviewRun -> navigateSafely("activity")
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.ReattachSource -> { navigateSafely("home"); homeViewModel.captureMessage.value = "Select the source again using Add context." }
                is com.halo.runtime.cognition.context.ContextualNextActionTarget.ReviewSaveResult -> Unit // Home owns the reviewed exact-result dialog.
            } } catch(cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
            catch(error: Exception) { graph.interactionContext.message.value = error.message ?: "Source unavailable" }
        }
    }
    LaunchedEffect(Unit) {
        ManualDependencyGraph.scopedSpeechMediaControls
        ManualDependencyGraph.accessoryActionOwners.navigationEvents.collectLatest(::navigateSafely)
    }

    LaunchedEffect(Unit) {
        ManualDependencyGraph.contextualCapture.navigation.collectLatest { event ->
            when(event) {
                com.halo.app.capture.ContextualCaptureNavigation.Ask -> navigateSafely("home")
                is com.halo.app.capture.ContextualCaptureNavigation.Study -> navigateSafely("study?captureSource=${android.net.Uri.encode(event.objectId)}")
                is com.halo.app.capture.ContextualCaptureNavigation.OpenNote -> navigateSafely("notebook/note/${android.net.Uri.encode(event.objectId)}")
                com.halo.app.capture.ContextualCaptureNavigation.Memory -> navigateSafely("notebook/memory?section=Memories")
            }
        }
    }
    com.halo.app.capture.ContextualCaptureSheet(ManualDependencyGraph.contextualCapture,
        onVisionSetup = { navigateSafely("settings/intelligence/roles") })
    com.halo.app.study.ExtractionReviewSheet(ManualDependencyGraph.extractionReview)
    LaunchedEffect(Unit) {
        ManualDependencyGraph.extractionReview.navigation.collectLatest { destination ->
            try { when(destination.kind) {
                "study" -> navigateSafely("study?captureSource=${android.net.Uri.encode(destination.noteId)}")
                "ask" -> {
                    ManualDependencyGraph.visualAttachments.remove()
                    ManualDependencyGraph.interactionContext.selectWorkspace(destination.noteId)
                    ManualDependencyGraph.homeViewModel.selectedMode.value = com.halo.runtime.cognition.context.CognitiveOperatingMode.ASK
                    navigateSafely("home")
                }
                else -> navigateSafely("notebook/note/${android.net.Uri.encode(destination.noteId)}")
            } } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
            catch (error: Exception) { ManualDependencyGraph.extractionReview.navigationFailed(error.message ?: "Could not open the reviewed note; it remains saved") }
        }
    }

    BoxWithConstraints {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    var lastWorkingRoot by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf("home") }
    val bellOpen = currentRoute?.startsWith("activity") == true || currentRoute?.startsWith("notifications") == true
    LaunchedEffect(currentRoute) {
        if (!bellOpen) primaryNavigationRoute(currentRoute)?.takeIf { candidate -> bottomNavItems.any { it.route == candidate } }
            ?.let { lastWorkingRoot = it }
    }

    androidx.activity.compose.BackHandler(currentRoute == "home" && screenMode && !kidsMode) {
        if (screenFull) screenFull = false else screenMode = false
    }
    val developerRouteBlocked = currentRoute?.let {
        com.halo.app.ui.screens.settings.isDeveloperDestination(it)
    } == true && !ManualDependencyGraph.storage.getBoolean("halo_developer_tools_enabled", false)
    LaunchedEffect(currentRoute, developerRouteBlocked) {
        if (developerRouteBlocked) {
            navController.popBackStack()
            performNavigation("advanced_settings")
        }
    }
    val mini = backStackEntry?.destination?.route == "mini_halo"
    LaunchedEffect(mini) { onCompactChanged(mini) }
    val editingWorkspace = backStackEntry?.destination?.route?.let {
        it.startsWith("notebook/note/") || it.startsWith("notebook/canvas/") || it.startsWith("notebook/study/") || it.startsWith("studio") || it.startsWith("file_tools")
    } == true
    val shellOrbVisible = !mini && currentRoute != "guided_setup"
    var hintDismissed by androidx.compose.runtime.saveable.rememberSaveable {
        androidx.compose.runtime.mutableStateOf(ManualDependencyGraph.storage.getBoolean("interface4_orb_hint_seen", false))
    }
    val zone5GuideSession = androidx.compose.runtime.saveable.rememberSaveable(
        saver = com.halo.app.ui.zone5.Zone5GuideSession.saver(ManualDependencyGraph.storage)) {
        com.halo.app.ui.zone5.Zone5GuideSession(ManualDependencyGraph.storage)
    }
    fun dismissOrbHint() {
        hintDismissed = true
        ManualDependencyGraph.storage.putBoolean("interface4_orb_hint_seen", true)
    }
    val contextualRoute = if (currentRoute == "home" && screenMode) "screen" else currentRoute
    val pageContextBinding = remember { com.halo.app.context.CurrentPageContextBinding(
        ManualDependencyGraph.interactionContext, ManualDependencyGraph.workspaceContext::versionFor) }
    val contextObjectId = com.halo.app.context.CurrentPageContextBinding.objectArgument(currentRoute)
        ?.let { backStackEntry?.arguments?.getString(it) }
    var contextNotice by remember(backStackEntry) { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var contextJob by remember { androidx.compose.runtime.mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var showTypedMessage by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    androidx.compose.runtime.DisposableEffect(backStackEntry, contextObjectId) {
        onDispose { contextJob?.cancel(); contextJob = null }
    }
    val pageActions = remember { androidx.compose.runtime.mutableStateOf<com.halo.app.ui.presence.ShellPageProjection?>(null) }
    val pageObjectId = contextObjectId ?: backStackEntry?.arguments?.getString("sessionId") ?: backStackEntry?.arguments?.getString("projectId")
        ?: backStackEntry?.arguments?.getString("sourceId")
    val pageOwnerFilter: (com.halo.app.ui.presence.ShellPageOwner) -> Boolean = remember(kidsMode, contextualRoute, pageObjectId, backStackEntry?.id) { { owner ->
        ShellOrbCatalog.allowsPageProjection(owner, kidsMode) && owner.navigationEntryId == backStackEntry?.id &&
            ShellOrbCatalog.pageOwnerMatches(owner, contextualRoute, pageObjectId)
    }
    }
    val utilityBand = remember { androidx.compose.runtime.mutableStateOf<com.halo.app.ui.presence.ShellUtilityProjection?>(null) }
    val livePageActions = pageActions.value?.takeIf { pageOwnerFilter(it.owner) }
    BindCurrentScreenContext(ManualDependencyGraph.currentScreenContext, backStackEntry?.id, contextualRoute,
        livePageActions, ownerLifecycle, shellOrbVisible && !kidsMode)
    val currentContextObjectId = if (contextualRoute?.substringBefore("?") == "file_tools") livePageActions?.owner?.objectId else contextObjectId
    androidx.compose.runtime.DisposableEffect(livePageActions?.owner) {
        onDispose { contextJob?.cancel(); contextJob = null }
    }

    val orbDestinations = remember(kidsMode) { ShellOrbCatalog.globalDestinations(kidsMode) }
    val orbContext = remember(contextualRoute, kidsMode, currentContextObjectId, livePageActions) {
        val page = if (!kidsMode && currentContextObjectId != null)
            listOf(com.halo.app.ui.presence.HaloOrbContextAction("page-context", "Use this page as context", HaloGlyph.NOTE)) else emptyList()
        val actions = livePageActions?.actions?.map { com.halo.app.ui.presence.HaloOrbContextAction("page:${it.id}", it.title, it.glyph,
            enabled = it.enabled, disabledReason = if (it.enabled) null else livePageActions.owner.disabledReasonFor(it.id), pageLease = livePageActions) }
            ?: if (kidsMode && contextualRoute != "home") ShellOrbCatalog.context(contextualRoute, true) else emptyList()
        actions.filterNot { it.id.endsWith(".back") || it.title == "Back" && it.glyph == HaloGlyph.PREVIOUS } + page +
            if (!kidsMode && contextualRoute != "home") listOf(com.halo.app.ui.presence.HaloOrbContextAction("type-message", "Type a message", HaloGlyph.NOTE)) else emptyList()
    }
    val orbOverride = remember { androidx.compose.runtime.mutableStateOf<com.halo.app.ui.presence.ShellOrbOverride?>(null) }
                val liveHome by homeViewModel.uiState.collectAsStateWithLifecycle()
                val guideStarting by homeViewModel.listeningRequested.collectAsStateWithLifecycle()
                val guideSubmission by homeViewModel.textSubmission.collectAsStateWithLifecycle()
                val voiceFields by com.halo.app.ui.components.VoiceFieldCancellation.activeFields.collectAsStateWithLifecycle()
    val shellGuideIdle = voiceFields.isEmpty() && (!kidsMode || orbOverride.value?.interaction?.canStop != true) && !guideStarting && !guideSubmission.busy && !guideSubmission.needsRecovery && !liveHome.inputStatus.capturing &&
                        !liveHome.speechActive && !liveHome.speechProcessing &&
                        liveHome.runtimeState == com.halo.app.ui.glass.material.HaloRuntimeState.Idle &&
                        (liveHome.sessionState == com.halo.sdk.provider.CognitiveSessionState.Idle ||
                            liveHome.sessionState is com.halo.sdk.provider.CognitiveSessionState.Completed ||
                            liveHome.sessionState is com.halo.sdk.provider.CognitiveSessionState.Failed)
    androidx.compose.runtime.CompositionLocalProvider(
        com.halo.app.ui.theme.LocalHaloDecorationPaused provides (!shellGuideIdle || zone5GuideSession.presentationActive ||
            livePageActions?.owner?.guidanceBlocked == true || showTypedMessage ||
            WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current) > 0),
        com.halo.app.ui.zone5.LocalZone5HelpReadAloud provides { text ->
            com.halo.app.ui.components.HaloVoiceTextActions(text, onText = {}, allowDictation = false, readText = text)
        },
        com.halo.app.ui.workspace.LocalWorkspaceExport provides if (kidsMode) null else exportOwner::request,
        com.halo.app.ui.presence.LocalShellHaloOrb provides shellOrbVisible,
        com.halo.app.ui.presence.LocalShellOrbOverride provides orbOverride,
        com.halo.app.ui.presence.LocalShellPageActions provides pageActions,
        com.halo.app.ui.zone5.LocalZone5GuideSession provides zone5GuideSession,
        com.halo.app.ui.presence.LocalShellUtilityBand provides utilityBand,
        com.halo.app.ui.presence.LocalShellPageOwnerFilter provides pageOwnerFilter) {
    ShellTypedMessageSheet(homeViewModel, showTypedMessage && shellOrbVisible && !kidsMode) { showTypedMessage = false }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (shellOrbVisible) ShellFooterViewport(
                Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
                val dispatchContext: (com.halo.app.ui.presence.HaloOrbContextAction) -> Unit = { action ->
                        if (!action.enabled) Unit
                        else if (action.id.startsWith("page:")) {
                            action.invokePageAction(pageActions.value, pageOwnerFilter)
                        }
                        else if (kidsMode && action.id == "study") ShellOrbCatalog.directContextRoute(action, kidsMode)?.let(::navigateSafely)
                        else if (action.id == "type-message") showTypedMessage = true
                        else if (action.id == "page-context") {
                            val id = currentContextObjectId
                            val route = currentRoute
                            if (id != null && route != null && contextJob?.isActive != true) {
                                contextJob = shellScope.launch {
                                    try {
                                        val expected = if (contextualRoute?.substringBefore("?") == "file_tools") livePageActions?.owner?.canonicalSourceVersion else null
                                        pageContextBinding.bind(route, id, expected)
                                        contextNotice = "Page added as context"
                                    } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                                    catch (_: Exception) { contextNotice = "Page changed or unavailable. Select it again." }
                                }
                            }
                        } else if (action.id == "new-note") homeViewModel.createNote()
                        else action.catalog?.let { homeViewModel.requestOrbCatalog(it); navigateSafely("home") }
                    }
                val inbox by ManualDependencyGraph.notificationInboxSource.state.collectAsStateWithLifecycle()
                val activity by ManualDependencyGraph.activityViewModel.uiState.collectAsStateWithLifecycle()
                HaloZone(contextualRoute, (this@BoxWithConstraints.maxHeight -
                    WindowInsets.safeDrawing.asPaddingValues().calculateTopPadding() -
                    WindowInsets.safeDrawing.asPaddingValues().calculateBottomPadding()).coerceAtLeast(0.dp),
                    compact = this@BoxWithConstraints.maxHeight < 520.dp || WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current) > 0,
                    actions = orbContext, onAction = dispatchContext, onNavigate = ::navigateSafely,
                    attentionCount = if (kidsMode) 0 else inbox.items.count { it.active } + activity.events.filter { it.status == com.halo.app.ui.screens.activity.ActivityStatus.PENDING }.mapNotNull { it.reviewRunId }.distinct().size,
                    utility = {
                        com.halo.app.ui.components.HaloReadAloudBar(allowVoiceSettings = !kidsMode,
                            onVoiceSettings = { navigateSafely("settings/voice/output") })
                        contextNotice?.let { Text(uiText(it), Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall) }
                        if (currentRoute?.startsWith("activity") == true || currentRoute == "notifications")
                            BellSubviewControls(currentRoute, ::navigateSafely, { navController.popBackStack() })
                        utilityBand.value?.takeIf { pageOwnerFilter(it.owner) }?.let { com.halo.app.ui.presence.RenderShellUtilityBand(it) }
                    }, orb = { zoneOrbSize ->
                val scopedOrb = orbOverride.value.takeIf { kidsMode && currentRoute == "home" }
                if (scopedOrb != null) com.halo.app.ui.presence.HaloOrbLauncher(
                    scopedOrb.signal, scopedOrb.interaction, emptySet(), {}, scopedOrb.onPrimary, scopedOrb.onStop,
                    onTools = {}, showToolCatalog = false, destinations = orbDestinations, onNavigate = ::navigateSafely,
                    contextActions = orbContext, onContextAction = dispatchContext, size = zoneOrbSize)
                else com.halo.app.ui.presence.HomeOrbControl(homeViewModel, onRequestPermissions, ::navigateSafely,
                    size = zoneOrbSize, destinations = orbDestinations, onNavigate = ::navigateSafely,
                    contextActions = orbContext, onContextAction = dispatchContext, hint = null, onDismissHint = ::dismissOrbHint)
                }, destinations = orbDestinations,
                    entryId = backStackEntry?.id,
                    nextStep = livePageActions?.owner?.nextStep,
                    kids = kidsMode,
                    profile = { if (!kidsMode) com.halo.app.ui.components.PrivacyModeControl(detail = true) },
                    guideIdle = shellGuideIdle,
                    composer = contextualRoute == "home" && !kidsMode,
                    profileStatus = { com.halo.app.ui.components.PrivacyModeStatus() })
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Row(Modifier.fillMaxSize().padding(innerPadding).consumeWindowInsets(innerPadding)
            .semantics { testTagsAsResourceId = true }.testTag("halo-working-area")) {
        Column(Modifier.weight(1f).fillMaxSize()) {
        kidsLoadError?.let { Text(uiText(it), Modifier.padding(16.dp)) }
        if (setupSession && backStackEntry?.destination?.route != "guided_setup") TextButton(onClick = { navigateSafely("guided_setup") }) { Text(uiText("Return to guided setup")) }
        Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            if (contextualRoute != "screen") com.halo.app.ui.theme.HaloAmbientBackdrop(Modifier.matchParentSize())
            SharedTransitionLayout {
            com.halo.app.ui.design.HaloLabBoundary(
                enabled = currentRoute?.let { com.halo.app.ui.screens.settings.isDeveloperDestination(it) } == true,
            ) {
            if (!developerRouteBlocked) NavHost(
                navController = navController,
                startDestination = if (initialSetupNeeded) "guided_setup" else Screen.Home.route,
                modifier = Modifier.widthIn(max = 1040.dp).fillMaxSize(),
                enterTransition = { if (reducedMotion) androidx.compose.animation.EnterTransition.None else fadeIn(tween(com.halo.app.ui.design.HaloMotion.pageEnterMs)) },
                exitTransition = { if (reducedMotion) androidx.compose.animation.ExitTransition.None else fadeOut(tween(com.halo.app.ui.design.HaloMotion.pageExitMs)) },
                popEnterTransition = { if (reducedMotion) androidx.compose.animation.EnterTransition.None else fadeIn(tween(com.halo.app.ui.design.HaloMotion.pageEnterMs)) },
                popExitTransition = { if (reducedMotion) androidx.compose.animation.ExitTransition.None else fadeOut(tween(com.halo.app.ui.design.HaloMotion.pageExitMs)) },
            ) {
                composable("mini_halo") {
                    val activity = com.halo.app.ui.mini.miniHaloActivityOwner(androidx.compose.ui.platform.LocalContext.current)
                    androidx.activity.compose.BackHandler(enabled = activity is com.halo.app.ui.mini.MiniHaloActivity) {
                        homeViewModel.cancelVoiceInput()
                        activity?.finish()
                    }
                    com.halo.app.ui.mini.MiniHaloScreen(homeViewModel, onRequestPermissions,
                        sharedTransitionScope = this@SharedTransitionLayout,
                        animatedVisibilityScope = this@composable,
                        allowSharedOrb = com.halo.app.ui.presence.canShareHaloOrb(
                            activity !is com.halo.app.ui.mini.MiniHaloActivity, reducedMotion),
                        onOpen = { screen ->
                        if (activity is com.halo.app.ui.mini.MiniHaloActivity) {
                            activity.openFullHaloFromMini(screen)
                        } else navigateSafely(screen)
                    },
                        onClose = {
                            homeViewModel.cancelVoiceInput()
                            if (activity is com.halo.app.ui.mini.MiniHaloActivity) {
                                activity.finish()
                            } else if (!navController.popBackStack()) {
                                // In-app Mini is a destination, not a new window:
                                // closing it returns to Home instead of hiding Halo.
                                navController.navigateToPrimary(Screen.Home.route)
                            }
                        })
                }
                composable("guided_setup") {
                    LaunchedEffect(Unit) {
                        setupSession = true
                        // The welcome wizard is offered once, never imposed on every
                        // app restart. Its stage remains resumable from Settings.
                        if (initialSetupNeeded) setupStore.dismissAutomaticLaunch()
                    }
                    com.halo.app.ui.onboarding.HaloSetupScreen(setupStore, onOpen = ::navigateSafely, onExit = {
                        setupStore.dismissAutomaticLaunch()
                        setupSession = false
                        navController.navigate("home") { popUpTo("guided_setup") { inclusive = true }; launchSingleTop = true }
                    })
                }
                composable(Screen.Home.route) {
                    if (kidsMode) com.halo.app.ui.screens.kids.KidsModeScreen(homeViewModel, onRequestPermissions,
                        onOpenCanvas = { id -> navigateSafely("notebook/canvas/${android.net.Uri.encode(id)}") })
                    else Column(Modifier.fillMaxSize()) {
                        if (screenMode) {
                            val orbUi by homeViewModel.uiState.collectAsStateWithLifecycle()
                            val orbStarting by homeViewModel.listeningRequested.collectAsStateWithLifecycle()
                            val orbSubmission by homeViewModel.textSubmission.collectAsStateWithLifecycle()
                            val screenDensity = androidx.compose.ui.platform.LocalDensity.current
                            androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalDensity provides
                                androidx.compose.ui.unit.Density(screenDensity.density, com.halo.app.screen.screenAmbientFontScale(screenDensity.fontScale, screenFull))) {
                            com.halo.app.screen.HaloScreen(ManualDependencyGraph.screenStore, screenFull, { screenFull = it },
                            onOpen = ::navigateSafely, onTalk = {
                                screenMode = false; screenFull = false
                                val current = homeViewModel.uiState.value
                                if (!current.microphonePermissionGranted) onRequestPermissions()
                                else if (!current.speechReady) navigateSafely("voice_settings")
                                else homeViewModel.startListening()
                            }, onChat = { screenMode = false; screenFull = false },
                            orbControl = { size -> com.halo.app.ui.presence.HomeOrbControl(homeViewModel, onRequestPermissions,
                                onOpen = { route ->
                                    if (route == "home") { screenMode = false; screenFull = false }
                                    navigateSafely(route)
                                }, size = size) },
                            orbActive = orbStarting || orbUi.inputStatus.capturing || orbUi.speechActive || orbUi.speechProcessing || orbSubmission.busy ||
                                orbUi.runtimeState == com.halo.app.ui.glass.material.HaloRuntimeState.Recognizing ||
                                orbUi.runtimeState == com.halo.app.ui.glass.material.HaloRuntimeState.Speaking ||
                                orbUi.sessionState !is com.halo.sdk.provider.CognitiveSessionState.Completed &&
                                orbUi.sessionState !is com.halo.sdk.provider.CognitiveSessionState.Failed &&
                                orbUi.sessionState != com.halo.sdk.provider.CognitiveSessionState.Idle,
                            onQuickNote = { screenFull = false; homeViewModel.createNote() })
                            }
                        } else HomeScreen(
                        surfaceSwitcher = { com.halo.app.screen.HomeSurfaceSwitch(false,
                            { screenMode = it; if (!it) screenFull = false },
                            compact = androidx.compose.ui.platform.LocalDensity.current.fontScale >= 1.5f) },
                        onOpenCapture = { id -> navigateSafely("notebook/note/${android.net.Uri.encode(id)}") },
                        onDailyAction = { action -> navigateSafely(dailyOwnerRoute(action)) },
                        viewModel = homeViewModel,
                        onConfigureVision = { navigateSafely("settings/intelligence/roles") },
                        onOpenNotificationInbox = { navigateSafely("notifications") },
                        onOpenActivity = { navigateSafely(Screen.Activity.route) },
                        onContextPrivacy = { navigateSafely("settings/intelligence/context") },
                        onAssistantSetup = { navigateSafely("android_assistant") },
                        onOpenProvider = { navigateSafely("settings/intelligence/providers/${android.net.Uri.encode(it)}") },
                        onRequestMicrophonePermission = onRequestPermissions,
                        sharedTransitionScope = this@SharedTransitionLayout,
                        animatedVisibilityScope = this@composable,
                        allowSharedOrb = com.halo.app.ui.presence.canShareHaloOrb(true, reducedMotion)
                    )
                    }
                }
                composable("screen/organizer?recordId={recordId}", arguments = listOf(navArgument("recordId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry ->
                    val model: OrganizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel(key = "organizer:${entry.id}", factory = EverydayViewModelFactory {
                        OrganizerViewModel(studyContext.applicationContext as com.halo.app.HaloApplication, entry.savedStateHandle, entry.arguments?.getString("recordId"))
                    })
                    OrganizerScreen(model, onBack = { if (!navController.popBackStack()) navigateSafely("screen") },
                        onClocks = { navigateSafely(EverydayRoutes.CLOCKS) }, onBrief = { navigateSafely(EverydayRoutes.BRIEF) },
                        onOpenNote = { navigateSafely("notebook/note/${android.net.Uri.encode(it)}") })
                }
                composable(EverydayRoutes.CLOCKS) { entry ->
                    val model: WorldClockViewModel = androidx.lifecycle.viewmodel.compose.viewModel(key = "clocks:${entry.id}", factory = EverydayViewModelFactory { WorldClockViewModel(entry.savedStateHandle) })
                    WorldClockScreen(model, onBack = { if (!navController.popBackStack()) navigateSafely("screen") })
                }
                composable("screen/brief?briefId={briefId}", arguments = listOf(navArgument("briefId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry ->
                    val model: EverydayBriefViewModel = androidx.lifecycle.viewmodel.compose.viewModel(key = "brief:${entry.id}", factory = EverydayViewModelFactory {
                        EverydayBriefViewModel(studyContext.applicationContext as com.halo.app.HaloApplication, entry.arguments?.getString("briefId"), entry.savedStateHandle)
                    })
                    EverydayBriefScreen(model, onBack = { if (!navController.popBackStack()) navigateSafely("screen") },
                        onSources = { navigateSafely(EverydayRoutes.SOURCES) }, onOrganizer = { navigateSafely(EverydayRoutes.ORGANIZER) },
                        onOpenFact = { model.openFact(it, ::navigateSafely) })
                }
                composable(EverydayRoutes.SOURCES) { entry ->
                    val model: SourcesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(key = "sources:${entry.id}", factory = EverydayViewModelFactory {
                        SourcesViewModel(studyContext.applicationContext as com.halo.app.HaloApplication, entry.savedStateHandle)
                    })
                    SourcesScreen(model, null, null, onBack = { if (!navController.popBackStack()) navigateSafely("screen") },
                        onSource = { id, item -> navigateSafely(EverydayRoutes.source(id, item)) },
                        onOrganizer = { navigateSafely(EverydayRoutes.organizer(it)) }, onLocal = { model.openLocal(it, ::navigateSafely) })
                }
                composable("screen/source?sourceId={sourceId}&itemId={itemId}", arguments = listOf(
                    navArgument("sourceId") { type = NavType.StringType; defaultValue = "" },
                    navArgument("itemId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry ->
                    val model: SourcesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(key = "source:${entry.id}", factory = EverydayViewModelFactory {
                        SourcesViewModel(studyContext.applicationContext as com.halo.app.HaloApplication, entry.savedStateHandle)
                    })
                    SourcesScreen(model, entry.arguments?.getString("sourceId"), entry.arguments?.getString("itemId"),
                        onBack = { if (!navController.popBackStack()) navigateSafely("screen") },
                        onSource = { id, item -> navigateSafely(EverydayRoutes.source(id, item)) },
                        onOrganizer = { navigateSafely(EverydayRoutes.organizer(it)) }, onLocal = { model.openLocal(it, ::navigateSafely) })
                }
                composable("study?captureSource={captureSource}&goal={goal}&sourceVersion={sourceVersion}&sourceReference={sourceReference}", arguments = listOf(
                    navArgument("captureSource") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("goal") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("sourceVersion") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("sourceReference") { type = NavType.StringType; nullable = true; defaultValue = null }
                )) { entry ->
                    val model: com.halo.app.ui.screens.study.StudyHomeViewModel = viewModel(
                        factory = com.halo.app.ui.screens.study.StudyHomeViewModel.Factory(ManualDependencyGraph.studyUseCases, ManualDependencyGraph.workspaceRepository, ManualDependencyGraph.workspaceFileRepository, ManualDependencyGraph.studySourceResolver,ManualDependencyGraph.studyLessonStore, executionStorage = ManualDependencyGraph.storage, versionReader = ManualDependencyGraph.workspaceContext::versionFor))
                    LaunchedEffect(model, entry.arguments?.getString("captureSource"), entry.arguments?.getString("sourceVersion"), entry.arguments?.getString("sourceReference")) {
                        entry.arguments?.getString("captureSource")?.let { id ->
                            val encoded = entry.arguments?.getString("sourceReference")
                            // A malformed exact reference must never become a whole-note fallback.
                            model.selectInitialSource(id, entry.arguments?.getString("sourceVersion"),
                                sourceReference = encoded?.let { payload -> runCatching {
                                    com.halo.app.data.study.StudyJson.decodeSources(payload, emptyList(), null).singleOrNull()
                                }.getOrNull() }, exactReferenceRequired = encoded != null)
                        }
                    }
                    com.halo.app.ui.screens.study.StudyHomeScreen(model,
                        onResume = { id -> navigateSafely("notebook/study/${android.net.Uri.encode(id)}") },
                        onReview = { id -> navigateSafely("notebook/study/${android.net.Uri.encode(id)}?review=true") },
                        onNotebook = {
                            ManualDependencyGraph.notebookViewModel.setFilter(com.halo.app.ui.screens.notebook.NotebookFilter.NOTES)
                            navigateSafely("notebook")
                        },
                        onStartVoiceMode = requestVoiceModeFromSurface,
                        initialSourceId = entry.arguments?.getString("captureSource"),
                        initialGoal = entry.arguments?.getString("goal"))
                }
                composable("activity?runId={runId}", arguments = listOf(navArgument("runId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry ->
                    ActivityScreen(ManualDependencyGraph.activityViewModel, focusRunId = entry.arguments?.getString("runId"),
                        onHome = { navController.navigateToPrimary("home") },
                        onReviewRun = interactionViewModel::reviewRun, onOpenObject = { id ->
                        shellScope.launch {
                            val item = ManualDependencyGraph.workspaceUseCases.getObject(id)
                            val route = when (item?.type) {
                                com.halo.app.data.notebook.WorkspaceObjectType.NOTE -> if (item.contentRef == "file-tools:$id") "file_tools?objectId=${android.net.Uri.encode(id)}" else "notebook/note/$id"
                                com.halo.app.data.notebook.WorkspaceObjectType.CONVERSATION -> "notebook/conversation/$id"
                                com.halo.app.data.notebook.WorkspaceObjectType.MEMORY -> "notebook/memory/$id"
                                WorkspaceObjectType.CANVAS -> "notebook/canvas/$id"
                                com.halo.app.data.notebook.WorkspaceObjectType.FILE,
                                com.halo.app.data.notebook.WorkspaceObjectType.MEDIA -> "notebook/file/$id"
                                com.halo.app.data.notebook.WorkspaceObjectType.ARTIFACT -> if (item.contentRef.startsWith("studio:")) "studio?projectId=${android.net.Uri.encode(id)}" else if (item.contentRef.startsWith("canvas:")) "notebook/canvas/$id" else "notebook/file/$id"
                                null -> Screen.Notebook.route
                            }
                            navigateSafely(route)
                        }
                    })
                }

                composable(Screen.Notebook.route) { notebookEntry ->
                    val requestLocalSearch by notebookEntry.savedStateHandle.getStateFlow("openLocalSearch", false).collectAsStateWithLifecycle()
                    val notebookViewModel = ManualDependencyGraph.notebookViewModel
                    DisposableEffect(notebookViewModel, notebookEntry) {
                        notebookViewModel.bindSavedView(notebookEntry.savedStateHandle)
                        onDispose { }
                    }
                    LaunchedEffect(notebookViewModel) {
                        notebookViewModel.navigationEvents.collectLatest { event ->
                            when (event) {
                                is NotebookNavigation.OpenMemoryHub -> navigateSafely("notebook/memory?section=${event.section}" + event.noteId?.let { "&noteId=${android.net.Uri.encode(it)}" }.orEmpty())
                                is NotebookNavigation.OpenNote -> navigateSafely("notebook/note/${event.id}")
                                is NotebookNavigation.OpenConversation -> navigateSafely("notebook/conversation/${event.id}")
                                is NotebookNavigation.OpenFile -> openWorkspaceFile(event.id)
                                is NotebookNavigation.OpenMemory -> navigateSafely("notebook/memory/${event.id}")
                                is NotebookNavigation.OpenStudio -> navigateSafely("studio?projectId=${android.net.Uri.encode(event.id)}")
                                is NotebookNavigation.OpenFileTools -> navigateSafely("file_tools?objectId=${android.net.Uri.encode(event.id)}")
                                is NotebookNavigation.OpenCanvas -> navigateSafely("notebook/canvas/${event.id}" + (event.nodeId?.let { "?nodeId=${android.net.Uri.encode(it)}" } ?: ""))
                                is NotebookNavigation.ReviewAutomation -> navigateSafely("automation_review/${android.net.Uri.encode(event.routineId)}/${android.net.Uri.encode(event.suggestionId)}")
                                NotebookNavigation.ReviewCapabilities -> navigateSafely("ai_settings")
                                is NotebookNavigation.OpenStudy -> navigateSafely("notebook/study/${event.sessionId}?review=${event.review}")
                                is NotebookNavigation.StartStudyFromSource -> navigateSafely(
                                    "study?captureSource=${android.net.Uri.encode(event.objectId)}")
                            }
                        }
                    }
                    NotebookScreen(notebookViewModel, rootRequest = workspaceRootRequest,
                        librarySession = ManualDependencyGraph.notebookLibrarySession,
                        requestLocalSearch = requestLocalSearch,
                        onLocalSearchOpened = { notebookEntry.savedStateHandle["openLocalSearch"] = false },
                        onOpenStudy = { navigateSafely(Screen.Study.route) },
                        onSkills = { navigateSafely("skills") },
                        onOpenModels = { navigateSafely("settings/intelligence/on-device") },
                        onOpenStudio = { navigateSafely("studio") },
                        onOpenFileTools = { navigateSafely("file_tools") },
                        onOpenCanvasLibrary = { navigateSafely("canvases") },
                        onStartVoiceMode = requestVoiceModeFromSurface)
                }

                composable(
                    "notebook/note/{noteId}",
                    arguments = listOf(navArgument("noteId") { type = NavType.StringType })
                ) { entry ->
                    val noteId = entry.arguments?.getString("noteId")
                    if (noteId == null) {
                        LaunchedEffect(Unit) { navController.popBackStack() }
                    } else {
                        val editorViewModel: NoteEditorViewModel = viewModel(
                            key = "note-editor-$noteId",
                            factory = NoteEditorViewModel.Factory(
                                noteId, ManualDependencyGraph.notebookUseCases,
                                ManualDependencyGraph.notebookAssetRepository,
                                ManualDependencyGraph.notebookDocumentRepository,
                                ManualDependencyGraph.workspaceUseCases,
                                ManualDependencyGraph.aiProviderRouter,
                                { (!ManualDependencyGraph.kidsPreferences.enabled.value || ManualDependencyGraph.kidsPreferences.cloudAllowed.value) && ManualDependencyGraph.storage.readRuntimeAiContextPolicy().allowCloudWorkspace },
                                imageService = ManualDependencyGraph.workspaceImageService,
                                study = ManualDependencyGraph.studyUseCases,
                                structuredResults = ManualDependencyGraph.notebookStructuredResults,
                            )
                        )
                        NoteEditorScreen(
                            viewModel = editorViewModel,
                            onBack = { navController.popBackStack() },
                            onOpenStudy = { sessionId -> navigateSafely("notebook/study/$sessionId") },
                            onOpenCanvas = { canvasId, selectionId ->
                                navigateSafely("notebook/canvas/${android.net.Uri.encode(canvasId)}?nodeId=${android.net.Uri.encode(selectionId)}")
                            },
                            onStartStudySetup = { goal, reference ->
                                val source = "study?captureSource=${android.net.Uri.encode(noteId)}&sourceReference=${android.net.Uri.encode(com.halo.app.data.study.StudyJson.encodeSources(listOf(reference)))}"
                                navigateSafely(source + (goal?.takeIf { it.isNotBlank() }?.let {
                                    "&goal=${android.net.Uri.encode(it)}"
                                } ?: ""))
                            },
                            onReviewMemory = { id -> navigateSafely("notebook/memory?noteId=${android.net.Uri.encode(id)}") },
                            onOpenStudio = { id, attachment -> navigateSafely("studio?sourceId=${android.net.Uri.encode(id)}&attachmentId=${android.net.Uri.encode(attachment)}") },
                            onOpenOffice = if (kidsMode) null else { id -> navigateSafely("file_tools?objectId=${android.net.Uri.encode(id)}") },
                            onExportCopy = if (kidsMode) null else { id, revision, format ->
                                check(ManualDependencyGraph.kidsPreferences.loadedState.value && !ManualDependencyGraph.kidsPreferences.enabled.value)
                                ManualDependencyGraph.workspaceTextDocuments.exportNote(id, revision, format)
                            },
                        )
                    }
                }

                composable(
                    "notebook/study/{sessionId}?review={review}",
                    arguments = listOf(navArgument("sessionId") { type = NavType.StringType }, navArgument("review") { type = NavType.BoolType; defaultValue = false })
                ) { entry ->
                    val sessionId = entry.arguments?.getString("sessionId")
                    if (sessionId == null) {
                        LaunchedEffect(Unit) { navController.popBackStack() }
                    } else {
                        val studyViewModel: StudyViewModel = viewModel(
                            key = "study-$sessionId",
                            factory = StudyViewModel.Factory(
                                sessionId,
                                ManualDependencyGraph.studyUseCases,
                                ManualDependencyGraph.studyTutorGateway,
                                lessons = ManualDependencyGraph.studyLessonStore,
                                workspace = ManualDependencyGraph.workspaceRepository,
                                notes = ManualDependencyGraph.notebookUseCases,
                                readerStorage = ManualDependencyGraph.storage,
                            ),
                        )
                        LaunchedEffect(studyViewModel) {
                            launch { studyViewModel.restartedLessons.collectLatest { id -> navigateSafely("notebook/study/${android.net.Uri.encode(id)}") } }
                            studyViewModel.savedNotes.collectLatest { id -> navigateSafely("notebook/note/${android.net.Uri.encode(id)}") }
                        }
                        StudyScreen(studyViewModel, startInReview = entry.arguments?.getBoolean("review") == true, onOpenSource = { id -> shellScope.launch {
                            val item = ManualDependencyGraph.workspaceUseCases.getObject(id)
                            val kind = if (item?.type == WorkspaceObjectType.NOTE) "note" else "file"
                            navigateSafely("notebook/$kind/${android.net.Uri.encode(id)}")
                        } }, onConfigureVision = { navigateSafely("settings/intelligence/roles") },
                            onStartVoiceMode = requestVoiceModeFromSurface, activeTools = ManualDependencyGraph.activeStudyToolsOwner) { navController.popBackStack() }
                    }
                }

                composable(
                    "notebook/canvas/{canvasId}?nodeId={nodeId}",
                    arguments = listOf(navArgument("canvasId") { type = NavType.StringType }, navArgument("nodeId") { type = NavType.StringType; nullable = true; defaultValue = null })
                ) { entry ->
                    val canvasId = entry.arguments?.getString("canvasId")
                    if (canvasId == null) {
                        LaunchedEffect(Unit) { navController.popBackStack() }
                    } else {
                        val canvasViewModel: CanvasEditorViewModel = viewModel(
                            key = "canvas-editor-$canvasId",
                            factory = CanvasEditorViewModel.Factory(
                                canvasId,
                                ManualDependencyGraph.notebookCanvasRepository,
                                workspace = ManualDependencyGraph.workspaceUseCases,
                                memoTranscriber = ManualDependencyGraph.localMemoTranscriber,
                                permitsAi = ManualDependencyGraph.workspaceMediaAiPolicy::permitsObject,
                                router = ManualDependencyGraph.aiProviderRouter,
                                allowCloudSharing = { (!ManualDependencyGraph.kidsPreferences.enabled.value || ManualDependencyGraph.kidsPreferences.cloudAllowed.value) && ManualDependencyGraph.storage.readRuntimeAiContextPolicy().allowCloudWorkspace },
                                imageService = ManualDependencyGraph.workspaceImageService,
                                assets = ManualDependencyGraph.notebookAssetRepository,
                                notes = ManualDependencyGraph.notebookUseCases,
                                study = ManualDependencyGraph.studyUseCases,
                            ),
                        )
                        androidx.compose.runtime.DisposableEffect(canvasViewModel) {
                            val token = ManualDependencyGraph.currentCanvasContext.attach(canvasViewModel::currentContextProjection)
                            val workflow = ManualDependencyGraph.canvasWorkflowBridge.attach(canvasViewModel)
                            onDispose {
                                ManualDependencyGraph.currentCanvasContext.detach(token)
                                ManualDependencyGraph.canvasWorkflowBridge.detach(workflow)
                            }
                        }
                        LaunchedEffect(canvasViewModel) {
                            canvasViewModel.navigationEvents.collectLatest { event ->
                                when (event) {
                                    is com.halo.app.ui.screens.notebook.CanvasEditorNavigation.OpenNote -> navigateSafely("notebook/note/${android.net.Uri.encode(event.id)}")
                                    is com.halo.app.ui.screens.notebook.CanvasEditorNavigation.OpenStudy -> navigateSafely("notebook/study/${android.net.Uri.encode(event.sessionId)}")
                                    is com.halo.app.ui.screens.notebook.CanvasEditorNavigation.StartStudyFromSource -> navigateSafely(
                                        "study?captureSource=${android.net.Uri.encode(event.noteId)}&goal=${android.net.Uri.encode(event.goal)}")
                                    is com.halo.app.ui.screens.notebook.CanvasEditorNavigation.AskAboutSelection -> {
                                        val sourceFile = event.sourceFile
                                        val pageInk = event.pageInk
                                        val pageNumber = event.pageNumber
                                        val selection = event.selection
                                        val selectionCanvasId = event.canvasId
                                        val selectionBookmarkId = event.selectionNodeId
                                        val validateSelection: suspend () -> Unit = {
                                            ManualDependencyGraph.workspaceUseCases.requireCurrentInkSelection(
                                                selectionCanvasId, selectionBookmarkId, requireNotNull(selection))
                                        }
                                        val crop = try {
                                            validateSelection()
                                            event.crop ?: if (sourceFile != null && pageInk != null &&
                                                pageNumber != null && selection != null) {
                                                com.halo.sdk.runtime.multimodal.MediaAssetContent(
                                                    com.halo.app.ui.screens.notebook.CanvasInkSelectionCropRenderer.renderPage(
                                                        ManualDependencyGraph.applicationContext, sourceFile, pageNumber,
                                                        pageInk, selection), "image/png")
                                            } else if (sourceFile != null || pageInk != null ||
                                                pageNumber != null || selection != null) {
                                                error("Selected source page is unavailable.")
                                            } else null
                                        } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                                        catch (_: Exception) {
                                            canvasViewModel.showNotice("Could not prepare the selected-region image. Try selecting again.")
                                            return@collectLatest
                                        }
                                        if (crop != null) {
                                            try {
                                                ManualDependencyGraph.visualAttachments.attachGeneratedImage(
                                                    crop.bytes, "Canvas selection", event.canvasId,
                                                    selection?.let { com.halo.app.data.notebook.InkSelectionBookmarkCodec.referenceText(it) },
                                                    validateSource = validateSelection,
                                                    commitSource = { commit ->
                                                        ManualDependencyGraph.workspaceUseCases.withCurrentInkSelection(
                                                            selectionCanvasId, selectionBookmarkId, requireNotNull(selection), commit)
                                                    })
                                            } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                                            catch (_: Exception) {
                                                canvasViewModel.showNotice(if (ManualDependencyGraph.visualAttachments.state.value != null)
                                                    "Remove the current image attachment before asking about an ink selection."
                                                else "Could not prepare the selected-region image. Try selecting again.")
                                                return@collectLatest
                                            }
                                        }
                                        ManualDependencyGraph.homeViewModel.selectedMode.value = com.halo.runtime.cognition.context.CognitiveOperatingMode.ASK
                                        ManualDependencyGraph.homeViewModel.requestInkSelectionAskPrompt()
                                        navigateSafely("home")
                                    }
                                    is com.halo.app.ui.screens.notebook.CanvasEditorNavigation.OpenObject -> {
                                        val item = event.objectRef
                                        val kind = when (item.type) {
                                            WorkspaceObjectType.NOTE -> if (item.contentRef == "file-tools:${item.id.value}") "file_tools" else "note"
                                            WorkspaceObjectType.CANVAS -> "canvas"
                                            WorkspaceObjectType.CONVERSATION -> "conversation"
                                            WorkspaceObjectType.MEMORY -> "memory"
                                            else -> if (item.contentRef.startsWith("studio:")) "studio" else if (item.contentRef.startsWith("canvas:")) "canvas" else "file"
                                        }
                                        navigateSafely(if (kind == "file_tools") "file_tools?objectId=${android.net.Uri.encode(item.id.value)}" else if (kind == "studio") "studio?projectId=${android.net.Uri.encode(item.id.value)}" else "notebook/$kind/${android.net.Uri.encode(item.id.value)}")
                                    }
                                }
                            }
                        }
                        CanvasEditorScreen(canvasViewModel, focusNodeId = entry.arguments?.getString("nodeId"), kidsMode = kidsMode,
                            onOpenStudio = { source, attachment -> navigateSafely("studio?sourceId=${android.net.Uri.encode(source)}&canvasId=${android.net.Uri.encode(canvasId)}" +
                                (attachment?.let { "&attachmentId=${android.net.Uri.encode(it)}" } ?: "")) }) { navController.popBackStack() }
                    }
                }

                composable("notebook/file/{objectId}",
                    arguments = listOf(navArgument("objectId") { type = NavType.StringType })) { entry ->
                    entry.arguments?.getString("objectId")?.let { id ->
                        WorkspaceObjectDetailScreen(id, "file", ManualDependencyGraph.workspaceUseCases,
                            onStudio = { sourceId -> navigateSafely("studio?sourceId=${android.net.Uri.encode(sourceId)}") },
                            onFileTools = { sourceId -> navigateSafely("file_tools?objectId=${android.net.Uri.encode(sourceId)}") }, onStudy = { sourceId ->
                            // Source preselection only; Study's own wizard owns
                            // the explicit device/cloud execution choice.
                            navigateSafely("study?captureSource=${android.net.Uri.encode(sourceId)}")
                        }) {
                            navController.popBackStack()
                        }
                    }
                }
                composable("workspace_handoff") {
                    com.halo.app.ui.workspace.WorkspaceHandoffRoute(onNavigate = { route ->
                        navController.popBackStack()
                        navigateSafely(route)
                    }, onBack = {
                        navController.popBackStack()
                        navigateSafely("notebook")
                    })
                }
                composable("file_tools?objectId={objectId}", arguments = listOf(navArgument("objectId") {
                    type = NavType.StringType; nullable = true; defaultValue = null
                })) { entry ->
                    com.halo.app.ui.workspace.WorkspaceFileToolsRoute(entry.arguments?.getString("objectId"), entry.savedStateHandle,
                        onBack = { navController.popBackStack() },
                        onOpenNote = { id -> navigateSafely("notebook/note/${android.net.Uri.encode(id)}") },
                        onOpenFile = { id -> navigateSafely("notebook/file/${android.net.Uri.encode(id)}") },
                        onOpenStudio = { id -> navigateSafely(if (id == null) "studio" else "studio?sourceId=${android.net.Uri.encode(id)}") },
                        onStudy = { id -> navigateSafely("study?captureSource=${android.net.Uri.encode(id)}") },
                        onOpenCanvas = { id, node -> navigateSafely("notebook/canvas/${android.net.Uri.encode(id)}?nodeId=${android.net.Uri.encode(node)}") })
                }
                composable("canvases") { entry ->
                    com.halo.app.ui.workspace.StudioRoute(null, null, null, null, entry.savedStateHandle,
                        onBack = { navController.popBackStack() }, onOpenFile = {},
                        onOpenCanvas = { id, node -> navigateSafely("notebook/canvas/${android.net.Uri.encode(id)}" +
                            (node?.let { "?nodeId=${android.net.Uri.encode(it)}" } ?: "")) }, canvasLibrary = true)
                }
                composable("studio?projectId={projectId}&sourceId={sourceId}&attachmentId={attachmentId}&canvasId={canvasId}&sourceVersion={sourceVersion}&handoffId={handoffId}",
                    arguments = listOf("projectId", "sourceId", "attachmentId", "canvasId", "sourceVersion", "handoffId").map {
                        navArgument(it) { type = NavType.StringType; nullable = true; defaultValue = null }
                    }) { entry ->
                    com.halo.app.ui.workspace.StudioRoute(entry.arguments?.getString("projectId"),
                        entry.arguments?.getString("sourceId"), entry.arguments?.getString("attachmentId"),
                        entry.arguments?.getString("canvasId"), entry.savedStateHandle,
                        onBack = { navController.popBackStack() },
                        onOpenFile = { navigateSafely("notebook/file/${android.net.Uri.encode(it)}") },
                        onOpenCanvas = { id, node -> navigateSafely("notebook/canvas/${android.net.Uri.encode(id)}" +
                            (node?.let { "?nodeId=${android.net.Uri.encode(it)}" } ?: "")) },
                        sourceVersion = entry.arguments?.getString("sourceVersion"), handoffId = entry.arguments?.getString("handoffId"))
                }
                composable("notebook/memory?section={section}&noteId={noteId}", arguments = listOf(
                    navArgument("section") { type = NavType.StringType; defaultValue = "Memories" },
                    navArgument("noteId") { type = NavType.StringType; nullable = true; defaultValue = null }
                )) { entry ->
                    val hub: com.halo.app.ui.screens.notebook.MemoryHubViewModel = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
                        @Suppress("UNCHECKED_CAST") override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T = ManualDependencyGraph.memoryHubViewModel() as T
                    })
                    val noteId = entry.arguments?.getString("noteId")
                    val captureMemoryCandidate = remember(noteId) { ManualDependencyGraph.contextualCapture.takeMemoryCandidate() }
                    val noteReview by androidx.compose.runtime.produceState<Pair<Boolean, com.halo.app.data.memory.MemoryCandidate?>>(false to null, noteId) {
                        value = true to noteId?.let { ManualDependencyGraph.notebookRepository.getNote(it) }?.takeIf { it.lifecycle == com.halo.app.data.notebook.WorkspaceLifecycle.ACTIVE }?.let {
                            val document = ManualDependencyGraph.notebookDocumentRepository.load(it.id)
                            val text = document?.blocks?.takeIf { blocks -> blocks.isNotEmpty() }?.let(com.halo.app.data.notebook.NotebookDocumentCodec::plainText) ?: it.body
                            com.halo.app.data.memory.MemoryCandidate(text, com.halo.app.data.notebook.WorkspaceObjectId(it.id), it.revision)
                        }
                    }
                    LaunchedEffect(Unit) { ManualDependencyGraph.notebookViewModel.navigationEvents.collectLatest { event ->
                        when (event) {
                            is NotebookNavigation.ReviewAutomation -> navigateSafely("automation_review/${android.net.Uri.encode(event.routineId)}/${android.net.Uri.encode(event.suggestionId)}")
                            NotebookNavigation.ReviewCapabilities -> navigateSafely("ai_settings")
                            is NotebookNavigation.OpenMemory -> navigateSafely("notebook/memory/${event.id}")
                            is NotebookNavigation.OpenNote -> navigateSafely("notebook/note/${event.id}")
                            is NotebookNavigation.OpenFile -> openWorkspaceFile(event.id)
                            else -> Unit
                        }
                    } }
                    if (noteId == null || noteReview.second != null) com.halo.app.ui.screens.notebook.MemoryHubScreen(hub, ManualDependencyGraph.notebookViewModel,
                        onBack = { navController.popBackStack() }, onOpenMemory = { navigateSafely("notebook/memory/$it") },
                        onSettings = { navigateSafely("memory_learning") }, initialSection = entry.arguments?.getString("section") ?: "Memories", initialCandidate = noteReview.second ?: captureMemoryCandidate)
                    else if (noteReview.first) androidx.compose.material3.TextButton({ navController.popBackStack() }) { Text(uiText("Original note is unavailable · Back")) }
                }
                composable("notebook/memory/{objectId}",
                    arguments = listOf(navArgument("objectId") { type = NavType.StringType })) { entry ->
                    entry.arguments?.getString("objectId")?.let { id ->
                        WorkspaceObjectDetailScreen(id, "memory", ManualDependencyGraph.workspaceUseCases,
                            onOpenSource = { item ->
                                val route = when (item.type) {
                                    WorkspaceObjectType.NOTE -> if (item.contentRef == "file-tools:${item.id.value}") "file_tools" else "note"
                                    WorkspaceObjectType.CONVERSATION -> "conversation"
                                    WorkspaceObjectType.MEMORY -> "memory"
                                    WorkspaceObjectType.CANVAS -> "canvas"
                                    WorkspaceObjectType.ARTIFACT -> if (item.contentRef.startsWith("studio:")) "studio" else if (item.contentRef.startsWith("canvas:")) "canvas" else "file"
                                    else -> "file"
                                }
                                navigateSafely(if (route == "file_tools") "file_tools?objectId=${android.net.Uri.encode(item.id.value)}" else if (route == "studio") "studio?projectId=${android.net.Uri.encode(item.id.value)}" else "notebook/$route/${item.id.value}")
                            }) {
                            navController.popBackStack()
                        }
                    }
                }

                composable(Screen.Devices.route) {
                    val viewModel = ManualDependencyGraph.devicesViewModel
                    LaunchedEffect(viewModel) {
                        viewModel.navigationEvents.collectLatest(::navigateSafely)
                    }
                    DevicesScreen(viewModel, onTestAudio = { navigateSafely("settings/voice/output") })
                }

                composable("device/{deviceId}", arguments = listOf(navArgument("deviceId") { type = NavType.StringType })) { entry ->
                    val viewModel = ManualDependencyGraph.devicesViewModel
                    val deviceId = entry.arguments?.getString("deviceId")
                    val state by viewModel.uiState.collectAsStateWithLifecycle()
                    val deviceKind = state.devices.firstOrNull { it.id == deviceId }?.kind
                    when {
                        deviceId == null -> navController.popBackStack()
                        deviceKind == com.halo.sdk.runtime.embodiment.DeviceKind.BUDDYBOT -> BuddyBotControlScreen(deviceId, viewModel) { navController.popBackStack() }
                        deviceKind == com.halo.sdk.runtime.embodiment.DeviceKind.HEYCYAN_GLASSES -> HeyCyanControlScreen(deviceId, viewModel) { navController.popBackStack() }
                        else -> navController.popBackStack()
                    }
                }

                composable("integrations") {
                    com.halo.app.ui.screens.settings.ConnectedAppsScreen(onBack = { navController.popBackStack() },
                        onActions = { navigateSafely("skills") })
                }
                composable("advanced/servers") {
                    val model: com.halo.app.ui.screens.integrations.McpServersViewModel = viewModel(
                        factory = com.halo.app.ui.screens.integrations.McpServersViewModel.Factory(ManualDependencyGraph.mcpSettingsService))
                    com.halo.app.ui.screens.integrations.IntegrationsScreen(model,
                        onBack = { navController.popBackStack() }, onServer = { navigateSafely("advanced/servers/${android.net.Uri.encode(it)}") })
                }
                composable("advanced/servers/{serverId}", arguments = listOf(navArgument("serverId") { type = NavType.StringType })) { entry ->
                    val id = entry.arguments?.getString("serverId").orEmpty()
                    val model: com.halo.app.ui.screens.integrations.McpServerViewModel = viewModel(
                        key = "mcp:$id", factory = com.halo.app.ui.screens.integrations.McpServerViewModel.Factory(id, ManualDependencyGraph.mcpSettingsService))
                    com.halo.app.ui.screens.integrations.McpServerScreen(model, onBack = { navController.popBackStack() })
                }
                listOf("skills", "advanced/skills").forEach { skillRoute ->
                composable(skillRoute) {
                    SkillsScreen(
                        procedureStore = ManualDependencyGraph.learnedProcedureStore,
                        onUseWorkflow = { request -> navigateSafely("home"); homeViewModel.submitText(request) },
                        onIntegrations = { navigateSafely("integrations") },
                        appCapabilities = ManualDependencyGraph.appFunctionCapabilityIndex,
                        refreshAppCapabilities = { ManualDependencyGraph.appFunctionConsumer.refresh() },
                        screenControlAvailable = { com.halo.host.android.accessibility.HaloAccessibilityService.isEnabled },
                        providerRoleCheck = { skill ->
                            val capabilities = skill.requirements.filterIsInstance<com.halo.sdk.runtime.skills.SkillRequirement.ProviderCapability>().map { it.capability.uppercase() }
                            val role = when {
                                "vision" in skill.id.value || "IMAGE" in capabilities -> com.halo.sdk.provider.AiModelRole.VISION
                                skill.id.value == "halo.research" || "TOOLS" in capabilities -> com.halo.sdk.provider.AiModelRole.AGENTIC
                                else -> null
                            }
                            if (role == null) null else try {
                                kotlinx.coroutines.withTimeout(10_000) {
                                    ManualDependencyGraph.aiProviderRouter.resolveExecutionTarget(
                                        com.halo.sdk.provider.AiRequest(toolUseMode = if (role == com.halo.sdk.provider.AiModelRole.AGENTIC) com.halo.sdk.provider.ToolUseMode.REQUIRED else com.halo.sdk.provider.ToolUseMode.NONE),
                                        com.halo.sdk.provider.AiWorkloadSpec(
                                            requiredCapabilities = if (role == com.halo.sdk.provider.AiModelRole.VISION) setOf(com.halo.sdk.provider.AiCapability.TEXT, com.halo.sdk.provider.AiCapability.IMAGE) else setOf(com.halo.sdk.provider.AiCapability.TEXT),
                                            tools = if (role == com.halo.sdk.provider.AiModelRole.AGENTIC) com.halo.sdk.provider.AiFeatureRequirement.REQUIRED else com.halo.sdk.provider.AiFeatureRequirement.NOT_NEEDED,
                                            preferredRole = role))
                                }
                                null
                            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                                if (cancelled !is kotlinx.coroutines.TimeoutCancellationException) throw cancelled
                                "Needs ${role.name} model setup"
                            } catch (_: Exception) { "Needs ${role.name} model setup" }
                        },
                        executionService = ManualDependencyGraph.skillExecutionService,
                        skillRegistry = ManualDependencyGraph.skillRegistry,
                        onBack = { navController.popBackStack() },
                        toolRegistry = ManualDependencyGraph.toolRegistry,
                        availabilityResolver = ManualDependencyGraph.toolAvailabilityResolver,
                        capabilityCatalogue = ManualDependencyGraph.capabilityCatalogue,
                        onInstallCustomSkill = ManualDependencyGraph::installCustomSkillPackage,
                        instructionSource = ManualDependencyGraph.skillInstructionSource,
                        technical = skillRoute == "advanced/skills",
                        packageIssues = ManualDependencyGraph.customSkillPackages.issues,
                        onLocalModels = { navigateSafely("settings/intelligence/on-device") },
                        onModelRoles = { navigateSafely("settings/intelligence/roles") },
                        capabilityStatus = ManualDependencyGraph.capabilityStatusViewModel,
                        onRequestSkillAccess = onRequestSkillPermissions,
                    )
                }
                }

                composable("workload_diagnostics") {
                    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp)) {
                        com.halo.app.ui.design.HaloScreenHeader(uiText("Workload diagnostics"), navigation = { navController.popBackStack() })
                        com.halo.app.ui.screens.settings.WorkloadDiagnosticsPanel(ManualDependencyGraph.aiProviderRouter)
                    }
                }
                composable("advanced_settings") {
                    val viewModel = ManualDependencyGraph.settingsViewModel
                    LaunchedEffect(viewModel) { viewModel.navigationEvents.collectLatest(::navigateSafely) }
                    SettingsScreen(viewModel, initialAdvanced = true, onBack = { navController.popBackStack() },
                        onSetup = { stage -> setupStore.open(stage); setupSession = true; navigateSafely("guided_setup") })
                }

                composable("runtime_status") {
                    RuntimeScreen(
                        projection = ManualDependencyGraph.runtimeUiProjection,
                        catalogueSource = ManualDependencyGraph.capabilityCatalogue,
                        onBack = { navController.popBackStack() },
                        onOpenSystemCheck = { navigateSafely("system_check") }
                    )
                }

                listOf("system_check", "technical_report", "developer_check").forEach { checkRoute ->
                composable(checkRoute) {
                    val context = LocalContext.current
                    val viewModel = remember(context) {
                        SystemCheckViewModel(
                            appContext = context.applicationContext,
                            providerRouter = ManualDependencyGraph.aiProviderRouter,
                            modelManager = ManualDependencyGraph.modelManager,
                            inferenceLedger = ManualDependencyGraph.inferenceLedger,
                            // RUNTIME-056: the Phone abilities list reports real descriptor
                            // availability instead of hardcoded "Available" rows.
                            toolRegistry = ManualDependencyGraph.toolRegistry,
                            toolAvailabilityResolver = ManualDependencyGraph.toolAvailabilityResolver,
                            remoteProviderRegistry = ManualDependencyGraph.providerGraph.remoteProviderPresenceRegistry,
                            remoteCredentialPresent = { key ->
                                !ManualDependencyGraph.storage.getString(key, null).isNullOrBlank()
                            },
                            // MINING-P0-001 native residency vs execution lease truth.
                            runtimeSnapshotSource = ManualDependencyGraph.runtimeSnapshotManager,
                            // MINING-P2-001 passive active-surface count for the presentation section.
                            presentationProjection = ManualDependencyGraph.presentationProjection,
                            payloadStore = ManualDependencyGraph.contentPayloadStore,
                            agentRuns = ManualDependencyGraph.agentRunStore,
                            speechDiagnostics = ManualDependencyGraph.speechDiagnosticRunner,
                            voicePipelineReport = { ManualDependencyGraph.voicePipelineTraceRecorder.report() },
                            localProfileSource = ManualDependencyGraph.localInferenceProfileSource,
                            modelProfileRepository = ManualDependencyGraph.modelRuntimeProfileRepository,
                            memoryPressure = { ManualDependencyGraph.providerGraph.nativeResourceCoordinator.budget.value.pressure },
                        )
                    }
                    if (checkRoute == "system_check") com.halo.app.ui.screens.settings.CheckUpScreen(
                        viewModel = viewModel, onBack = { navController.popBackStack() },
                        onIntelligence = { navigateSafely("ai_settings") },
                        onVoice = { navigateSafely("voice_settings") },
                    ) else if (checkRoute == "technical_report") com.halo.app.ui.screens.settings.TechnicalReportScreen(
                        viewModel = viewModel, onBack = { navController.popBackStack() },
                    ) else SystemCheckScreen(
                        viewModel = viewModel,
                        onOpenPhoneSandbox = { navigateSafely("phone_control_sandbox") },
                        onOpenAutomationSandbox = { navigateSafely("automation_sandbox") },
                        onOpenIntelligence = { navigateSafely("ai_settings") },
                        onOpenVoiceSettings = { navigateSafely("voice_settings") },
                        onBack = { navController.popBackStack() }
                    )
                }

                }
                composable("automation_sandbox") {
                    com.halo.app.ui.screens.settings.AutomationSandboxScreen(onBack = { navController.popBackStack() })
                }
                composable("phone_control_sandbox") {
                    com.halo.app.ui.screens.settings.PhoneControlSandboxScreen(onBack = { navController.popBackStack() })
                }

                composable("notebook/conversations") {
                    ConversationsListScreen(
                        conversationStore = ManualDependencyGraph.conversationStore,
                        onOpenConversation = { navigateSafely("notebook/conversation/$it") },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    "notebook/conversation/{conversationId}",
                    arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
                ) { entry ->
                    val conversationId = entry.arguments?.getString("conversationId")
                    val scope = rememberCoroutineScope()
                    if (conversationId == null) {
                        LaunchedEffect(Unit) { navController.popBackStack() }
                    } else {
                        val history by ManualDependencyGraph.conversationStore.history.collectAsStateWithLifecycle()
                        val conversations by ManualDependencyGraph.conversationStore.conversations.collectAsStateWithLifecycle()
                        // NB08: the raw history flow retains turns in Trash so
                        // they can be restored. A direct/deep-linked detail must
                        // revalidate the Workspace lifecycle before displaying them.
                        val available by androidx.compose.runtime.produceState<Boolean?>(
                            initialValue = null, key1 = conversationId, key2 = conversations
                        ) {
                            value = ManualDependencyGraph.conversationStore
                                .isConversationAvailable(conversationId)
                        }
                        when (available) {
                            null -> com.halo.app.ui.design.HaloProgressPresentation(
                                uiText("Loading…"))
                            false -> Column(
                                Modifier.fillMaxSize().padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(uiText("Chat unavailable"),
                                    style = MaterialTheme.typography.titleLarge)
                                Text(uiText("This chat may be in Trash. Restore it from Notebook to read it again."),
                                    style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = { navController.popBackStack() }) {
                                    Text(uiText("Back to Notebook"))
                                }
                            }
                            true -> {
                                val turns = history.filter { it.conversationId == conversationId }
                                ConversationDetailScreen(
                                    conversationId = conversationId,
                                    savedTitle = conversations.firstOrNull { it.id == conversationId }?.title,
                                    turns = turns,
                                    onContinue = {
                                        homeViewModel.openConversation(conversationId)
                                        navController.navigateToPrimary("home")
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }

                composable(Screen.Settings.route) {
                    val viewModel = ManualDependencyGraph.settingsViewModel
                    LaunchedEffect(viewModel) { viewModel.navigationEvents.collectLatest(::navigateSafely) }
                    SettingsScreen(viewModel, rootRequest = settingsRootRequest, onSetup = { stage -> setupStore.open(stage); setupSession = true; navigateSafely("guided_setup") })
                }

                composable("automation?routineId={routineId}&watchId={watchId}", arguments = listOf(
                    navArgument("routineId") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("watchId") { type = NavType.StringType; nullable = true; defaultValue = null })) { entry ->
                    com.halo.app.ui.screens.settings.AutomationScreen(ManualDependencyGraph.routinesViewModel,
                        focusWatchId = entry.arguments?.getString("watchId"),
                        focusRoutineId = entry.arguments?.getString("routineId"), onBack = { navController.popBackStack() }, onNotifications = { navigateSafely("notification_settings") },
                        onActivity = { navigateSafely(Screen.Activity.route) }, onInbox = { navigateSafely("notifications") })
                }
                composable("automation_review/{routineId}/{suggestionId}") { entry ->
                    com.halo.app.ui.screens.settings.AutomationScreen(ManualDependencyGraph.routinesViewModel,
                        onBack={navController.popBackStack()},onNotifications={navigateSafely("notification_settings")},
                        onActivity={navigateSafely(Screen.Activity.route)},onInbox={navigateSafely("notifications")},
                        reviewRoutineId=entry.arguments?.getString("routineId"),
                        reviewSuggestionId=entry.arguments?.getString("suggestionId"))
                }
                composable("memory_learning") {
                    com.halo.app.ui.screens.settings.LearningSettingsScreen(onBack={navController.popBackStack()})
                }
                composable("notifications") {
                    val model: com.halo.app.ui.screens.notifications.NotificationInboxViewModel = viewModel(
                        factory = com.halo.app.ui.screens.notifications.NotificationInboxViewModel.Factory(ManualDependencyGraph.notificationInboxSource))
                    com.halo.app.ui.screens.notifications.NotificationInboxScreen(model,
                        onBack = { navController.popBackStack() }, onOpen = { navigateSafely("notifications/${android.net.Uri.encode(it)}") },
                        onReviewActivity = { navigateSafely("activity?runId=${android.net.Uri.encode(it)}") })
                }
                composable("notifications/{notificationKey}", arguments = listOf(navArgument("notificationKey") { type = NavType.StringType })) { entry ->
                    val key = entry.arguments?.getString("notificationKey").orEmpty()
                    val model: com.halo.app.ui.screens.notifications.NotificationDetailViewModel = viewModel(
                        key = "notification:$key", factory = com.halo.app.ui.screens.notifications.NotificationDetailViewModel.Factory(key,
                            ManualDependencyGraph.notificationInboxSource, ManualDependencyGraph.applicationContext, ManualDependencyGraph.notificationReplyDispatcher))
                    com.halo.app.ui.screens.notifications.NotificationDetailScreen(model,
                        onBack = { navController.popBackStack() }, onPrivacy = { navigateSafely("notification_settings") })
                }
                composable("notification_settings") {
                    com.halo.app.ui.screens.settings.NotificationSettingsScreen(ManualDependencyGraph.routinesViewModel,
                        onOpenInbox = { navigateSafely("notifications") }, onBack = { navController.popBackStack() })
                }
                composable("ai_settings") {
                    IntelligenceScreen(
                        control = ManualDependencyGraph.providerControlRepository,
                        onBack = { navController.popBackStack() },
                        onBrowseModels = { navigateSafely("settings/intelligence/models") },
                        onProviderSetup = { navigateSafely("settings/intelligence/providers") },
                        onRoles = { navigateSafely("settings/intelligence/roles") },
                        onDevice = { navigateSafely("settings/intelligence/on-device") },
                        onContext = { navigateSafely("settings/intelligence/context") },
                        onDiagnostics = { navigateSafely("system_check") },
                        onVisionLab = { navigateSafely("vision_lab") },
                        onAudioLab = { navigateSafely("local_audio_lab") },
                        onAdvanced = { navigateSafely("advanced_settings") },
                        onNotebookSearch = {
                            navigateSafely(Screen.Notebook.route)
                            navController.getBackStackEntry(Screen.Notebook.route).savedStateHandle["openLocalSearch"] = true
                        },
                        onUsage = { navigateSafely("settings/shared-requests") },
                    )
                }
                composable("local_audio_lab") {
                    val model: com.halo.app.ui.screens.settings.LocalAudioLabViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
                    com.halo.app.ui.screens.settings.LocalAudioLabScreen(model,
                        onBack = { navController.popBackStack() },
                        onModels = { navigateSafely("settings/intelligence/on-device") })
                }
                composable("vision_lab") {
                    val model: com.halo.app.ui.screens.settings.VisionLabViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
                    com.halo.app.ui.screens.settings.VisionLabScreen(model,
                        onBack = { navController.popBackStack() }, onPrivacy = { navigateSafely("settings/intelligence/context") },
                        onCamera = { navigateSafely("home") })
                }
                composable("provider_setup") {
                    com.halo.app.ui.screens.settings.ProviderCenterScreen(ManualDependencyGraph.providerControlRepository,
                        onBack = { navController.popBackStack() }, onProvider = { navigateSafely(if (it == com.halo.providers.litert.LiteRtLocalProvider.ProviderIds.LITERT) "settings/intelligence/on-device" else "settings/intelligence/providers/${android.net.Uri.encode(it)}") })
                }
                composable("settings/intelligence/providers") {
                    com.halo.app.ui.screens.settings.ProviderCenterScreen(ManualDependencyGraph.providerControlRepository,
                        onBack = { navController.popBackStack() }, onProvider = { navigateSafely(if (it == com.halo.providers.litert.LiteRtLocalProvider.ProviderIds.LITERT) "settings/intelligence/on-device" else "settings/intelligence/providers/${android.net.Uri.encode(it)}") })
                }
                composable("settings/intelligence/providers/{providerId}") { entry ->
                    com.halo.app.ui.screens.settings.ProviderDetailScreen(ManualDependencyGraph.providerControlRepository,
                        providerId = entry.arguments?.getString("providerId").orEmpty(),
                        onBack = { navController.popBackStack() },
                        onModels = { navigateSafely("settings/intelligence/models?providerId=${android.net.Uri.encode(it)}") },
                        onAssignRole = { navigateSafely("settings/intelligence/roles") },
                        onDevice = { navigateSafely("settings/intelligence/on-device") },
                        onImages = { navigateSafely("settings/intelligence/images/${android.net.Uri.encode(entry.arguments?.getString("providerId").orEmpty())}") },
                        onDiagnostics = { navigateSafely("system_check") })
                }
                composable("settings/intelligence/images/{providerId}") { entry ->
                    val provider = entry.arguments?.getString("providerId").orEmpty()
                    com.halo.app.ui.screens.settings.ImageModelsScreen(ManualDependencyGraph.workspaceImageService, provider,
                        onBack = { navController.popBackStack() }, onSetup = { navigateSafely("settings/intelligence/providers/${android.net.Uri.encode(provider)}") })
                }
                composable("model_browser") {
                    com.halo.app.ui.screens.settings.ModelBrowserScreen(ManualDependencyGraph.modelBrowserViewModel,
                        onBack = { navController.popBackStack() }, onProvider = { navigateSafely(if (it == com.halo.providers.litert.LiteRtLocalProvider.ProviderIds.LITERT) "settings/intelligence/on-device" else "settings/intelligence/providers/${android.net.Uri.encode(it)}") })
                }
                composable("settings/intelligence/models?providerId={providerId}&role={role}", arguments = listOf(
                    androidx.navigation.navArgument("providerId") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                    androidx.navigation.navArgument("role") { type = androidx.navigation.NavType.StringType; defaultValue = "" })) { entry ->
                    com.halo.app.ui.screens.settings.ModelBrowserScreen(ManualDependencyGraph.modelBrowserViewModel,
                        onBack = { navController.popBackStack() }, onProvider = { navigateSafely(if (it == com.halo.providers.litert.LiteRtLocalProvider.ProviderIds.LITERT) "settings/intelligence/on-device" else "settings/intelligence/providers/${android.net.Uri.encode(it)}") },
                        initialProvider = entry.arguments?.getString("providerId")?.takeIf { it.isNotBlank() },
                        initialRole = entry.arguments?.getString("role")?.let { raw -> com.halo.sdk.provider.AiModelRole.entries.firstOrNull { it.name == raw } })
                }
                composable("settings/shared-requests") {
                    com.halo.app.ui.screens.settings.SharedAnswerHistoryScreen(ManualDependencyGraph.sharedAnswerHistory,
                        onBack = { navController.popBackStack() })
                }
                composable("settings/intelligence/usage") {
                    com.halo.app.ui.screens.settings.IntelligenceUsageScreen(ManualDependencyGraph.inferenceLedger,
                        onBack = { navController.popBackStack() }, onDiagnostics = { navigateSafely("system_check") })
                }
                composable("settings/intelligence/roles") {
                    com.halo.app.ui.screens.settings.ModelRolesScreen(ManualDependencyGraph.providerControlRepository,
                        onBack = { navController.popBackStack() }, onPick = { navigateSafely("settings/intelligence/models?role=${it.name}") },
                        evidence = ManualDependencyGraph.localRoleEvidenceController,
                        onExplore = { ManualDependencyGraph.intelligenceViewModel.exploreLocalCandidates(it); navigateSafely("settings/intelligence/on-device") })
                }
                composable("settings/intelligence/on-device") {
                    com.halo.app.ui.screens.settings.OnDeviceModelsScreen(ManualDependencyGraph.intelligenceViewModel, onBack = { navController.popBackStack() }, onConfigureRoles = { navigateSafely("settings/intelligence/roles") }, onAudioLab = { navigateSafely("local_audio_lab") }, onVisionLab = { navigateSafely("vision_lab") }, onLocalSearch = { navigateSafely(Screen.Notebook.route) })
                }
                composable("local_model_lab") {
                    com.halo.app.ui.screens.settings.OnDeviceModelsScreen(ManualDependencyGraph.intelligenceViewModel,
                        onBack = { navController.popBackStack() }, onConfigureRoles = { navigateSafely("settings/intelligence/roles") },
                        onAudioLab = { navigateSafely("local_audio_lab") }, onVisionLab = { navigateSafely("vision_lab") }, technical = true)
                }
                composable("settings/intelligence/context") {
                    com.halo.app.ui.screens.settings.ContextPrivacyScreen(ManualDependencyGraph.contextPrivacyViewModel,
                        onBack = { navController.popBackStack() },
                        onAdvanced = { navigateSafely("settings/intelligence/policy") },
                        onPermissions = { navigateSafely("permissions") })
                }
                composable("settings/voice/input") {
                    com.halo.app.ui.screens.settings.SpeechRecognitionSettingsScreen(ManualDependencyGraph.voiceSettingsViewModel,
                        onBack = { navController.popBackStack() }, onSpeechLab = { navigateSafely("settings/voice/speech-lab") })
                }
                composable("settings/voice/speech-lab") {
                    val lab = remember { com.halo.app.ui.screens.settings.SpeechLabViewModel(ManualDependencyGraph.speechDiagnosticRunner) }
                    com.halo.app.ui.screens.settings.SpeechLabScreen(lab, onBack = { navController.popBackStack() })
                }
                listOf("settings/voice/output", "advanced/voices").forEach { voiceRoute ->
                composable(voiceRoute) {
                    com.halo.app.ui.screens.settings.SpeechOutputSettings(ManualDependencyGraph.voiceSettingsViewModel,
                        technical = voiceRoute == "advanced/voices",
                        onElevenLabs = { navigateSafely("settings/voice/elevenlabs") }, onBack = { navController.popBackStack() })
                }
                }
                composable("settings/intelligence/policy") {
                    com.halo.app.ui.screens.settings.IntelligencePolicyScreen(ManualDependencyGraph.intelligenceViewModel,
                        onBack = { navController.popBackStack() }, onBrowseModels = { navigateSafely("settings/intelligence/on-device") })
                }
                composable("settings/voice/elevenlabs") {
                    val provider = ManualDependencyGraph.speechSynthesisRegistry.providers.filterIsInstance<com.halo.providers.elevenlabs.tts.ElevenLabsTtsProvider>().first()
                    com.halo.app.ui.screens.settings.ElevenLabsSettingsScreen(provider,
                        onBack = { navController.popBackStack() },
                        onTestVoice = { ManualDependencyGraph.haloSpeechOutputCoordinator.preview(provider.metadata.id) },
                        onUseProvider = { ManualDependencyGraph.speechSynthesisRegistry.selector.selectTts(provider.metadata.id) })
                }
                composable("assistant_diagnostics") {
                    AndroidAssistantScreen(ManualDependencyGraph.assistantRoleController,
                        audioAffinity = ManualDependencyGraph.haloSpeechOutputCoordinator.session.affinity,
                        showDiagnostics = true, onBack = { navController.popBackStack() })
                }
                composable("android_assistant") {
                    AndroidAssistantScreen(
                        ManualDependencyGraph.assistantRoleController,
                        // MINING-P0-001 interaction audio affinity: the coordinator that owns the
                        // audio leases owns this record, so it stays the single source of truth.
                        audioAffinity = ManualDependencyGraph.haloSpeechOutputCoordinator.session.affinity,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable("voice_settings") {
                    val viewModel = ManualDependencyGraph.voiceSettingsViewModel
                    LaunchedEffect(viewModel) {
                        viewModel.navigationEvents.collectLatest { if (it == "back") navController.popBackStack() }
                    }
                    VoiceSettingsScreen(viewModel, onBack = { navController.popBackStack() }, onSpeechOutput = { navigateSafely("settings/voice/output") },
                        onSpeechRecognition = { navigateSafely("settings/voice/input") })
                }

                composable("permissions") {
                    PermissionsScreen(
                        guideStore = setupStore,
                        onBack = { navController.popBackStack() },
                        onRequestPermissions = onRequestPermissions,
                        storageAccessRepository = ManualDependencyGraph.storageAccessRepository,
                        onOpenStorageBackup = { navigateSafely("storage_backup") },
                    )
                }
                composable("storage_backup") {
                    StorageBackupScreen(ManualDependencyGraph.storageBackupViewModel) { navController.popBackStack() }
                }
                composable("discovery") {
                    val viewModel = ManualDependencyGraph.pairingViewModel
                    LaunchedEffect(viewModel) {
                        viewModel.navigationEvents.collectLatest { if (it == "back") navController.popBackStack() }
                    }
                    PairingScreen(
                        viewModel = viewModel,
                        onRequestBluetoothPermissions = onRequestBluetoothPermissions,
                        onRequestBluetoothEnable = onRequestBluetoothEnable
                    )
                }
            }
            } // Lab boundary
            } // SharedTransitionLayout; external Activity cannot share across windows
        }
        }
    }
    }
    } // shell presence ownership
    }
}
