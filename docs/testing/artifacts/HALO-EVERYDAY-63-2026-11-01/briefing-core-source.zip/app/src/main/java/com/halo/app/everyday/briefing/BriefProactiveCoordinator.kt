package com.halo.app.everyday.briefing

import java.time.*
import kotlinx.coroutines.*

/** Once per scheduled period, through Halo's existing attention policy. Never starts audio or a fetch. */
class BriefProactiveCoordinator(private val repository: BriefRepository, private val briefs: EverydayBriefService,
    private val deliver: suspend (EverydayBrief) -> String, private val clock: Clock = Clock.systemUTC(),
    private val zone: () -> ZoneId = { ZoneId.systemDefault() }) {
    suspend fun runDue(): EverydayBrief? {
        val settings = repository.settings()
        val now = clock.instant(); val deviceZone = zone()
        val done = repository.deliveryKeys(now.minusSeconds(2 * 86400))
        val period = BriefSchedulePolicy.due(settings, now, deviceZone, done) ?: return null
        val document = briefs.build(period)
        // Building can suspend. Recheck the current opt-in, quiet hours, date/zone and schedule before delivery.
        val current = repository.settings()
        val actualNow = clock.instant()
        if (current.version != settings.version || deviceZone != zone() ||
            document.date != actualNow.atZone(deviceZone).toLocalDate() ||
            BriefSchedulePolicy.due(current, actualNow, deviceZone, done) != period) return document
        val key = BriefSchedulePolicy.key(document.date, deviceZone, period)
        if (!repository.claimDelivery(key, document.id, actualNow)) return document
        try {
            val latest = repository.settings()
            val state = if (latest.version != current.version || latest.quiet(clock.instant().atZone(zone()).toLocalTime())) "CANCELLED"
                else deliver(document)
            repository.finishDelivery(key, document.id, state)
        } catch (cancelled: CancellationException) {
            withContext(NonCancellable) { repository.finishDelivery(key, document.id, "CANCELLED") }
            throw cancelled
        } catch (_: Exception) { repository.finishDelivery(key, document.id, "FAILED") }
        return document
    }
}
