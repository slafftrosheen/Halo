plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
}

fun getGitCommitHash(): String {
  System.getenv("GIT_COMMIT")?.trim()?.takeIf { it.isNotEmpty() }?.let { return it.take(12) }
  return try {
    providers.exec {
      workingDir(rootDir)
      commandLine("git", "rev-parse", "--short=12", "HEAD")
    }.standardOutput.asText.get().trim().ifEmpty { "unknown" }
  } catch (_: Exception) {
    "unknown"
  }
}

fun getGitDirty(): Boolean {
  return try {
    providers.exec {
      workingDir(rootDir)
      commandLine("git", "status", "--porcelain")
    }.standardOutput.asText.get().trim().isNotEmpty()
  } catch (_: Exception) {
    false
  }
}

android {
  namespace = "com.halo.app"
  sourceSets.getByName("debug").assets.srcDir("schemas")
  compileSdk = 37

  defaultConfig {
    applicationId = "com.aistudio.braintool.xkqzps"
    minSdk = 26
    targetSdk = 37
    versionCode = 2
    versionName = "1.0-RC1"

    buildConfigField("String", "GIT_COMMIT", "\"${getGitCommitHash()}\"")
    buildConfigField("Boolean", "GIT_DIRTY", getGitDirty().toString())
    buildConfigField("String", "HALO_GIT_COMMIT", "\"${getGitCommitHash()}\"")
    buildConfigField("Boolean", "HALO_GIT_DIRTY", getGitDirty().toString())
    buildConfigField("String", "HALO_SOURCE_ID", "\"${getGitCommitHash()}${if (getGitDirty()) "+dirty" else ""}\"")

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    val customDebugKeystore = file("${rootDir}/debug.keystore")
    if (customDebugKeystore.exists()) {
      create("debugConfig") {
        storeFile = customDebugKeystore
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      val debugConfig = signingConfigs.findByName("debugConfig")
      if (debugConfig != null) {
        signingConfig = debugConfig
      }
    }
    create("benchmark") {
      initWith(getByName("release"))
      signingConfig = signingConfigs.findByName("debugConfig")
        ?: signingConfigs.getByName("debug")
      matchingFallbacks += listOf("release")
      isDebuggable = false
      isProfileable = true
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }
  buildFeatures {
    compose = true
    buildConfig = true
    aidl = true
  }
  ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
  }
  testOptions {
    unitTests {
      isIncludeAndroidResources = true
      all {
        // Windows native SQLite finalizers can outlive a Robolectric sandbox.
        // Bound worker lifetimes while retaining every test and the native driver.
        if (System.getProperty("os.name").startsWith("Windows")) {
          it.forkEvery = 16
          it.maxParallelForks = 1
        }
      }
    }
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
}


// pluginManager.withPlugin("com.android.application") {
//   pluginManager.apply("androidx.baselineprofile")
// }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  // Parse feed HTML locally; never use jsoup's network-fetch API.
  implementation("org.jsoup:jsoup:1.23.2")
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
  implementation("com.google.android.gms:play-services-wearable:20.0.1")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
  // implementation(project(":halo-xxx"))
  // implementation(project(":halo-xxx"))
  // implementation(project(":halo-xxx"))
  // implementation(project(":halo-xxx"))
  // implementation(project(":halo-xxx"))
  // implementation(project(":halo-xxx"))
  
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.fragment)
  implementation(libs.androidx.camera.camera2)
  implementation(libs.androidx.camera.core)
  implementation(libs.androidx.camera.lifecycle)
  implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.coil.compose)
  implementation("io.coil-kt:coil-svg:2.7.0")
  implementation("androidx.compose.animation:animation")
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.exifinterface)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.documentfile)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.profileinstaller)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  testImplementation("androidx.room:room-testing:2.8.5")
  implementation(libs.androidx.appsearch)
  implementation(libs.androidx.appsearch.local.storage)
  implementation(libs.androidx.work.runtime.ktx)
  implementation("com.airbnb.android:lottie-compose:6.7.1")
  // implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  // Uncomment to use Firestore:
  // implementation(libs.firebase.firestore)

  // Uncomment ALL FOUR of the following dependencies together to use Firebase Auth and Google
  // Sign-In via Credential Manager:
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.play.services.auth)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  implementation(project(":host-ink"))
  implementation("org.apache.commons:commons-compress:1.28.0")
  testImplementation(libs.mockwebserver)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(project(":providers:litert"))
  testImplementation(project(":providers:ollama"))
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  // Hermetic instrumentation layer: runs on an emulator with no hardware, network or credentials.
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  androidTestImplementation(libs.mockwebserver)
  androidTestImplementation(libs.okhttp.tls)
  androidTestImplementation(libs.androidx.uiautomator)
  androidTestImplementation(libs.litertlm.android)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  // "baselineProfile"(project(":baselineprofile"))
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.androidx.appsearch.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
  debugImplementation("com.squareup.leakcanary:leakcanary-android:2.14")
}
dependencies {
    implementation(project(":engines:ai"))
    implementation(project(":host-android"))
    implementation(project(":sdk:driver-sdk"))
    implementation(project(":sdk:host-sdk"))
    implementation(project(":sdk:provider-sdk"))
    implementation(project(":sdk:runtime-sdk"))
    implementation(project(":libraries:common"))
    implementation(project(":libraries:halo-cognition-language"))
}
dependencies {
    implementation(project(":runtime:events"))
    implementation(project(":runtime:commands"))
    implementation(project(":runtime:queries"))
    implementation(project(":runtime:scheduler"))
    implementation(project(":runtime:registry"))
    implementation(project(":runtime:kernel"))
    implementation(project(":runtime:speech"))
    implementation(project(":runtime:observer"))
    implementation(project(":engines:execution"))
    implementation(project(":libraries:testing"))
    implementation(project(":libraries:logging"))
}
dependencies {
    implementation(project(":runtime:services"))
    implementation(project(":engines:memory"))
    implementation(project(":engines:diagnostics"))
    implementation(project(":engines:reasoning"))
    implementation(project(":engines:interpretation"))
    implementation(project(":engines:speech"))
    implementation(project(":host-android"))
    implementation(project(":runtime:intents"))
    implementation(project(":runtime:plugins"))
    implementation(project(":runtime:speech"))
}
dependencies {
    implementation(project(":engines:perception"))
    implementation(project(":engines:reasoning"))
    implementation(project(":engines:interpretation"))
    implementation(project(":engines:planning"))
    implementation(project(":engines:execution"))
    implementation(project(":engines:agents"))
}
dependencies {
    implementation(project(":runtime:cognition"))
    implementation(project(":providers:litert"))
    implementation(project(":providers:ollama"))
    implementation(project(":providers:sherpa-stt"))
    implementation(project(":providers:android-tts"))
    implementation(project(":providers:elevenlabs-tts"))
    implementation(project(":providers:android-assistant"))
    implementation(project(":providers:openrouter"))
    implementation(project(":providers:openai"))
    implementation(project(":providers:anthropic"))
    implementation(project(":providers:gemini"))
    implementation(project(":providers:remote-groq"))
    implementation(project(":providers:remote-cerebras"))
    implementation(project(":providers:remote-opencode-zen"))
    implementation(project(":providers:remote-xai"))
    implementation(project(":providers:remote-opencode-companion"))
    implementation(project(":providers:remote-custom-openai-compatible"))
    implementation(project(":providers:remote-gemini-oauth"))
    implementation(project(":drivers:heycyan"))
    implementation(project(":drivers:simulator"))
}

tasks.register<Copy>("copyApkToReleases") {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.dir("outputs/apk/debug"))
    into(rootProject.layout.projectDirectory.dir("releases"))
    include("app-debug.apk")
    rename("app-debug.apk", "halo-alpha-debug.apk")
}

afterEvaluate {
    tasks.named("assembleDebug") {
        finalizedBy("copyApkToReleases")
    }
}

// Android 16+ discovery is optional; ordinary Halo skills remain independent.
dependencies {
  implementation("androidx.appfunctions:appfunctions:1.0.0-alpha12")
  ksp("androidx.appfunctions:appfunctions-compiler:1.0.0-alpha12")
}
