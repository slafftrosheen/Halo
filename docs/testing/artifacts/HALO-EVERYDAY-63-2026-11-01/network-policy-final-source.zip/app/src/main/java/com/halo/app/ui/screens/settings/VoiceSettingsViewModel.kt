package com.halo.app.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.halo.app.di.ProviderGraph
import com.halo.providers.sherpa.stt.*
import com.halo.sdk.runtime.Storage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LocaleOption(val displayName: String, val tag: String)

data class VoiceSettingsUiState(
    val models: Map<String, Boolean> = emptyMap(),
    val selectedProviderId: String = "AUTOMATIC",
    val selectedModelName: String = "Automatic",
    val residentModelId: String? = null,
    val recognitionPhase: String = "Loading",
    val recognitionMessage: String? = null,
    val sileroInstalled: Boolean = false,
    val downloadingModelId: String? = null,
    val downloadedBytes: Long = 0,
    val expectedBytes: Long = 0,
    val verifying: Boolean = false,
    val failedModelId: String? = null,
    val isTesting: Boolean = false,
    val testRecording: Boolean = false,
    val testResult: String? = null,
    val isInstalled: Boolean = false,
    val isDownloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val currentFileDownloading: String? = null,
    val downloadError: String? = null,
    val missingFiles: List<String> = emptyList(),
    val installedSizeBytes: Long = 0L,
    val selectedLocale: String = "en",
    val wearablePhoneFallback: Boolean = false,
    val availableLocales: List<LocaleOption> = listOf(
        LocaleOption("Automatic", "auto"), LocaleOption("Latviešu", "lv"),
        LocaleOption("English", "en"), LocaleOption("Русский", "ru"), LocaleOption("Deutsch", "de"),
        LocaleOption("Spanish", "es"), LocaleOption("French", "fr"), LocaleOption("Chinese", "zh"),
        LocaleOption("Japanese", "ja"), LocaleOption("Portuguese", "pt"), LocaleOption("Italian", "it")
    )
)

class VoiceSettingsViewModel(
    private val speechInventory: SpeechModelInventoryRepository,
    private val languageSettings: SpeechLanguageSettingsRepository,
    private val providerGraph: ProviderGraph? = null,
    private val storage: Storage? = null,
    val synthesisRegistry: com.halo.app.ai.SpeechSynthesisRegistry? = null,
    private val probe: SpeechRecognitionProbe? = null,
    val voiceExperience: com.halo.app.audio.VoiceExperienceSettingsRepository? = null
) : ViewModel() {
    private val _uiState = MutableStateFlow(VoiceSettingsUiState(
        wearablePhoneFallback = storage?.getBoolean("wearable_phone_fallback", false) ?: false))
    val uiState: StateFlow<VoiceSettingsUiState> = _uiState.asStateFlow()
    private val _navigationEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val navigationEvents = _navigationEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            languageSettings.loadAndMigrate()
            reloadable()?.refresh()?.join()
            speechInventory.refresh(languageSettings.languageMode.value)
            combine(speechInventory.state, languageSettings.languageMode,
                reloadable()?.readiness ?: MutableStateFlow(RecognitionReadiness())) { inventory, language, readiness -> Triple(inventory, language, readiness) }
                .collect { (inventory, language, readiness) ->
                    _uiState.value = _uiState.value.copy(models = inventory.models, sileroInstalled = inventory.sileroInstalled,
                        selectedProviderId = reloadable()?.selectedProviderId ?: "AUTOMATIC",
                        selectedModelName = readiness.modelName,
                        recognitionPhase = readiness.phase, recognitionMessage = readiness.message,
                        residentModelId = reloadable()?.residentModelId,
                        isInstalled = reloadable()?.availability?.value ?: inventory.installed, missingFiles = inventory.missingFiles,
                        installedSizeBytes = inventory.totalBytes, selectedLocale = language)
                }
        }
    }
    private var testJob: kotlinx.coroutines.Job? = null
    private val synthesisPreferenceLock = Any()
    private fun reloadable() = providerGraph?.providers?.speechRecognition as? ReloadableSpeechRecognitionProvider
    fun cloudSynthesisFallback(): Boolean = synchronized(synthesisPreferenceLock) { storage?.getBoolean(com.halo.app.ai.SpeechSynthesisRegistry.FALLBACK, true) ?: true }
    fun setCloudSynthesisFallback(enabled: Boolean) = synchronized(synthesisPreferenceLock) { storage?.putBoolean(com.halo.app.ai.SpeechSynthesisRegistry.FALLBACK, enabled) }
    fun setCloudSynthesisFallbackExpected(enabled: Boolean, expected: Boolean) = synchronized(synthesisPreferenceLock) {
        check(cloudSynthesisFallback() == expected) { "Synthesis fallback changed" }
        setCloudSynthesisFallback(enabled)
    }
    fun refreshState() { viewModelScope.launch {
        reloadable()?.refresh()?.join()
        speechInventory.refresh(languageSettings.languageMode.value)
    } }

    fun selectModel(providerId: String) {
        if (_uiState.value.isTesting || _uiState.value.isDownloading) return
        val spec = SherpaSpeechModelCatalog.recognitionModels.firstOrNull { it.providerId == providerId }
        if (spec != null && (!spec.supportsLanguage(_uiState.value.selectedLocale) || _uiState.value.models[spec.id] != true)) return
        reloadable()?.selectModel(providerId)
        _uiState.value = _uiState.value.copy(selectedProviderId = providerId)
        viewModelScope.launch { reloadable()?.refresh()?.join(); refreshState() }
    }
    fun removeModel(modelId: String) {
        removeModelGuarded(modelId, null)
    }
    fun removeModelExpected(modelId: String, expectedArtifactVersion: String) {
        removeModelGuarded(modelId, expectedArtifactVersion)
    }
    private fun removeModelGuarded(modelId: String, expectedArtifactVersion: String?) {
        val isVad = modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID
        val spec = SherpaSpeechModelCatalog.byId(modelId)
        if (!isVad && spec == null) return
        val state = _uiState.value
        if ((!isVad && (state.selectedProviderId == spec?.providerId || reloadable()?.metadata?.id == spec?.providerId)) || state.isTesting || state.isDownloading) return
        viewModelScope.launch {
            (if (expectedArtifactVersion == null) speechInventory.remove(modelId)
                else speechInventory.removeExpected(modelId, expectedArtifactVersion)).exceptionOrNull()
                ?.let { _uiState.value = _uiState.value.copy(downloadError = it.message) }
            refreshState()
        }
    }
    private var installJob: kotlinx.coroutines.Job? = null
    fun pauseModelDownload() { installJob?.cancel() }
    fun installModel(modelId: String) {
        if (_uiState.value.isDownloading || _uiState.value.isTesting) return
        installJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isDownloading = true, downloadingModelId = modelId,
                downloadProgress = 0f, downloadError = null, verifying = false, failedModelId = null)
            try {
                val result = speechInventory.install(modelId) { progress ->
                    _uiState.value = _uiState.value.copy(downloadProgress = progress.fraction,
                        currentFileDownloading = progress.currentFile, downloadedBytes = progress.downloadedBytes,
                        expectedBytes = progress.totalBytes, verifying = progress.verifying)
                }
                result.exceptionOrNull()?.let { _uiState.value = _uiState.value.copy(downloadError =
                    if (it is com.halo.sdk.provider.RemoteDispatchBlocked) com.halo.sdk.provider.MODEL_DOWNLOAD_BLOCKED_MESSAGE
                    else it.message, failedModelId = modelId) }
                reloadable()?.refresh()?.join()
                refreshState()
            } finally { _uiState.value = _uiState.value.copy(isDownloading = false, downloadingModelId = null) }
        }
    }
    fun startTest() {
        if (_uiState.value.isTesting || _uiState.value.isDownloading) return
        _uiState.value = _uiState.value.copy(isTesting = true, testRecording = true, testResult = null)
        testJob = viewModelScope.launch(start = kotlinx.coroutines.CoroutineStart.LAZY) {
            try {
                _uiState.value = _uiState.value.copy(testResult = probe?.run { recording ->
                    _uiState.value = _uiState.value.copy(testRecording = recording)
                } ?: "Speech probe unavailable")
            } catch (error: kotlinx.coroutines.CancellationException) { throw error }
            catch (error: Exception) { _uiState.value = _uiState.value.copy(testResult = error.message) }
            finally {
                testJob = null
                _uiState.value = _uiState.value.copy(isTesting = false, testRecording = false)
                refreshState()
            }
        }.also { it.start() }
    }
    fun finishTest() { probe?.finishCapture() }
    fun cancelTest() { testJob?.cancel(); probe?.cancel() }
    fun selectLocale(tag: String) {
        if (_uiState.value.isTesting) return
        viewModelScope.launch {
            selectLocaleAndAwait(tag)
        }
    }
    suspend fun selectLocaleAndAwait(tag: String, expected: String? = null) {
        check(!_uiState.value.isTesting && !_uiState.value.isDownloading) { "Finish the voice test or download first" }
        if (expected == null) languageSettings.select(tag) else languageSettings.selectExpected(tag, expected)
        reloadable()?.refresh()?.join()
        speechInventory.refresh(tag)
    }
    fun refreshConfiguredVoicePreferences() {
        _uiState.value = _uiState.value.copy(wearablePhoneFallback = voiceExperience?.state?.value?.wearablePhoneFallback
            ?: storage?.getBoolean("wearable_phone_fallback", false) ?: false)
    }
    val conversation = voiceExperience?.state ?: MutableStateFlow(com.halo.app.audio.VoiceExperienceSettings())
    fun updateConversation(value: com.halo.app.audio.VoiceExperienceSettings) { voiceExperience?.update(value) }
    fun setWearablePhoneFallback(enabled: Boolean) {
        voiceExperience?.let { it.update(it.state.value.copy(wearablePhoneFallback = enabled)) }
        storage?.putBoolean("wearable_phone_fallback", enabled)
        _uiState.value = _uiState.value.copy(wearablePhoneFallback = enabled)
    }
    fun goBack() { _navigationEvents.tryEmit("back") }
    override fun onCleared() { cancelTest(); super.onCleared() }
}
