package com.halo.providers.sherpa.stt

import com.halo.sdk.runtime.HaloDispatchers
import com.halo.sdk.provider.modelAcquisitionRevision
import com.halo.sdk.runtime.productionHaloDispatchers
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive

data class SpeechModelInventoryState(
    val loading: Boolean = true,
    val installed: Boolean = false,
    val totalBytes: Long = 0L,
    val missingFiles: List<String> = emptyList(),
    val selectedModel: String = "AUTOMATIC",
    val languageMode: String = "en",
    val models: Map<String, Boolean> = emptyMap(),
    val sileroInstalled: Boolean = false,
    val error: String? = null
)

interface SpeechModelInventoryRepository {
    val state: StateFlow<SpeechModelInventoryState>
    suspend fun refresh(languageMode: String? = null)
    /** No native load; fail closed when an owner cannot prove exact installed pins. */
    suspend fun verifyInstalled(modelId: String): Boolean = false
    suspend fun install(modelId: String, onProgress: (SpeechModelDownloadProgress) -> Unit): Result<Unit>
    suspend fun remove(modelId: String): Result<Unit>
    /** Exact local artifact metadata before destructive removal; unsupported owners fail closed. */
    suspend fun artifactVersion(modelId: String): String? = null
    suspend fun removeExpected(modelId: String, expectedArtifactVersion: String): Result<Unit> =
        Result.failure(UnsupportedOperationException("Exact artifact removal is unavailable"))
    suspend fun installOwned(modelId: String, owner: String, onProgress: (SpeechModelDownloadProgress) -> Unit): Result<Unit> =
        Result.failure(UnsupportedOperationException("Acquisition ownership is unavailable"))
    suspend fun removeOwned(modelId: String, owner: String): Result<Unit> =
        Result.failure(UnsupportedOperationException("Acquisition ownership is unavailable"))
    suspend fun installWhisperTiny(onProgress: (Float, String) -> Unit): Result<Unit> =
        install(SherpaSpeechModelCatalog.WHISPER_TINY_ID) { onProgress(it.fraction, it.currentFile) }
}

class DefaultSpeechModelInventoryRepository(
    private val speechRoot: () -> File,
    private val dispatchers: HaloDispatchers = productionHaloDispatchers(),
    private val selectedProviderId: () -> String = { "AUTOMATIC" },
    private val activeProviderId: () -> String? = { null },
    private val releaseSileroVad: suspend () -> Unit = {},
    private val allowSileroVadReload: () -> Unit = {},
    private val dispatchPolicy: com.halo.sdk.provider.RemoteDispatchPolicy = com.halo.sdk.provider.DenyRemoteDispatchPolicy,
) : SpeechModelInventoryRepository {
    private val _state = MutableStateFlow(SpeechModelInventoryState())
    override val state: StateFlow<SpeechModelInventoryState> = _state

    override suspend fun verifyInstalled(modelId: String): Boolean = withContext(dispatchers.io) {
        val spec = SherpaSpeechModelCatalog.byId(modelId)
            ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
            ?: return@withContext false
        val directory = if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot()
            else File(speechRoot(), spec.directoryName)
        val job = kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]
        try {
            SpeechModelInstaller.withTransferMutation(directory) {
                SherpaModelInstaller.verifyPinnedFiles(directory, spec) { job?.ensureActive() }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
        catch (_: Exception) { false }
    }

    override suspend fun refresh(languageMode: String?) {
        _state.value = _state.value.copy(loading = true, error = null)
        runCatching {
            withContext(dispatchers.io) {
                val models = SherpaSpeechModelCatalog.recognitionModels.associate { model ->
                    model.id to SherpaSpeechModelCatalog.isInstalled(File(speechRoot(), model.directoryName), model)
                }
                val selected = selectedProviderId()
                val spec = SherpaSpeechModelCatalog.resolve(selected) { models[it.id] == true }
                val language = languageMode ?: _state.value.languageMode
                SpeechModelInventoryState(
                    loading = false,
                    installed = spec != null && spec.supportsLanguage(language),
                    selectedModel = spec?.id ?: selected,
                    totalBytes = SherpaSpeechModelCatalog.recognitionModels.sumOf { model ->
                        model.files.sumOf { File(File(speechRoot(), model.directoryName), it.name).length() }
                    },
                    missingFiles = if (spec != null) emptyList() else {
                        val requested = SherpaSpeechModelCatalog.recognitionModels.firstOrNull { it.providerId == selected }
                        requested?.let { SherpaSpeechModelCatalog.missingFiles(File(speechRoot(), it.directoryName), it) } ?: emptyList()
                    },
                    models = models,
                    sileroInstalled = SherpaSpeechModelCatalog.isInstalled(speechRoot(), SherpaSpeechModelCatalog.sileroVad),
                    languageMode = languageMode ?: _state.value.languageMode
                )
            }
        }.onSuccess { _state.value = it }
            .onFailure { if (it is kotlinx.coroutines.CancellationException) throw it; _state.value = _state.value.copy(loading = false, error = it.message) }
    }

    override suspend fun install(modelId: String, onProgress: (SpeechModelDownloadProgress) -> Unit): Result<Unit> = installWithOwner(modelId, null, onProgress)
    override suspend fun installOwned(modelId: String, owner: String, onProgress: (SpeechModelDownloadProgress) -> Unit): Result<Unit> =
        installWithOwner(modelId, owner, onProgress)
    private suspend fun installWithOwner(modelId: String, owner: String?, onProgress: (SpeechModelDownloadProgress) -> Unit): Result<Unit> {
        val revision = dispatchPolicy.modelAcquisitionRevision()
        val spec = SherpaSpeechModelCatalog.byId(modelId)
            ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
            ?: return Result.failure(IllegalArgumentException("Unknown speech model"))
        val destination = withContext(dispatchers.io) {
            if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot()
            else File(speechRoot(), spec.directoryName)
        }
        return SpeechModelInstaller.install(spec, destination, owner, dispatchPolicy, revision, onProgress = onProgress).also {
            if (it.isSuccess && modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) allowSileroVadReload()
            refresh()
        }
    }

    override suspend fun removeOwned(modelId: String, owner: String): Result<Unit> = withContext(dispatchers.io) {
        var vadSuspended = false
        try {
            require(java.util.UUID.fromString(owner).toString() == owner)
            val spec = SherpaSpeechModelCatalog.byId(modelId) ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
                ?: error("Unknown speech model")
            val directory = if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot() else File(speechRoot(), spec.directoryName)
            SpeechModelInstaller.withTransferMutation(directory) {
                if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) {
                    if (spec.files.any { SherpaModelInstaller.hasOwnedFile(directory, it, owner) }) { vadSuspended = true; releaseSileroVad() }
                } else {
                    val selection = selectedProviderId()
                    val automatic = SherpaSpeechModelCatalog.resolve(selection) { SherpaSpeechModelCatalog.isInstalled(File(speechRoot(), it.directoryName), it) }
                    check(selection != spec.providerId && automatic != spec && activeProviderId() != spec.providerId) { "The speech model is selected or in use" }
                }
                SherpaModelInstaller.removeOwnedFiles(directory, spec, owner)
            }
            refresh()
            Result.success(Unit)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            if (vadSuspended) runCatching { allowSileroVadReload() }
            throw cancelled
        } catch (error: Exception) {
            if (vadSuspended) runCatching { allowSileroVadReload() }
            Result.failure(error)
        }
    }

    override suspend fun remove(modelId: String): Result<Unit> = withContext(dispatchers.io) {
        val spec = SherpaSpeechModelCatalog.byId(modelId) ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
            ?: return@withContext Result.failure(IllegalArgumentException("Unknown speech model"))
        val directory = if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot() else File(speechRoot(), spec.directoryName)
        SpeechModelInstaller.withTransferMutation(directory) { removeCurrent(modelId) }
    }
    override suspend fun artifactVersion(modelId: String): String? = withContext(dispatchers.io) {
        val spec = SherpaSpeechModelCatalog.byId(modelId) ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
            ?: return@withContext null
        val directory = if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot() else File(speechRoot(), spec.directoryName)
        val names = spec.files.map { it.name }
        val files = directory.listFiles().orEmpty().filter { file -> names.any { file.name == it || file.name.startsWith("$it.") } }
        val material = spec.toString() + "\u0000" + files.sortedBy { it.name }.joinToString("\u0000") { "${it.name}|${it.length()}|${it.lastModified()}" }
        "speech-artifact:" + java.security.MessageDigest.getInstance("SHA-256").digest(material.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
    override suspend fun removeExpected(modelId: String, expectedArtifactVersion: String): Result<Unit> = withContext(dispatchers.io) {
        val spec = SherpaSpeechModelCatalog.byId(modelId) ?: SherpaSpeechModelCatalog.sileroVad.takeIf { it.id == modelId }
            ?: return@withContext Result.failure(IllegalArgumentException("Unknown speech model"))
        val directory = if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) speechRoot() else File(speechRoot(), spec.directoryName)
        SpeechModelInstaller.withTransferMutation(directory) {
            if (artifactVersion(modelId) != expectedArtifactVersion) Result.failure(IllegalStateException("Speech artifact changed after review"))
            else removeCurrent(modelId)
        }
    }
    private suspend fun removeCurrent(modelId: String): Result<Unit> = withContext(dispatchers.io) {
        try {
            if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) {
                releaseSileroVad()
                val root = speechRoot().canonicalFile
                val model = File(root, SherpaSpeechModelCatalog.SILERO_VAD_FILE).canonicalFile
                require(model.parentFile == root) { "Invalid VAD model file" }
                val proof = File(root, "${SherpaSpeechModelCatalog.SILERO_VAD_FILE}.verified").canonicalFile
                require(proof.parentFile == root) { "Invalid VAD verification file" }
                val partial = File(root, "${SherpaSpeechModelCatalog.SILERO_VAD_FILE}.partial").canonicalFile
                require(partial.parentFile == root) { "Invalid VAD partial file" }
                SherpaModelInstaller.withFileMutation(root) {
                    check(!model.exists() || model.delete()) { "Unable to remove VAD model" }
                    check(!proof.exists() || proof.delete()) { "Unable to remove VAD verification file" }
                    check(!partial.exists() || partial.delete()) { "Unable to remove partial VAD download" }
                    File(root, model.name + ".acquired").delete()
                }
                refresh()
                return@withContext Result.success(Unit)
            }
            val spec = requireNotNull(SherpaSpeechModelCatalog.byId(modelId))
            val selection = selectedProviderId()
            val automatic = SherpaSpeechModelCatalog.resolve(selection) {
                SherpaSpeechModelCatalog.isInstalled(File(speechRoot(), it.directoryName), it)
            }
            check(selection != spec.providerId && automatic != spec && activeProviderId() != spec.providerId) {
                "Select another speech model before deleting this model."
            }
            val root = speechRoot().canonicalFile
            val directory = File(root, spec.directoryName).canonicalFile
            require(directory.parentFile == root) { "Invalid speech model directory" }
            SherpaModelInstaller.withFileMutation(directory) { check(!directory.exists() || directory.deleteRecursively()) { "Unable to remove speech model" } }
            refresh()
            Result.success(Unit)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) runCatching { allowSileroVadReload() }
            throw cancelled
        } catch (error: Exception) {
            if (modelId == SherpaSpeechModelCatalog.SILERO_VAD_ID) runCatching { allowSileroVadReload() }
            Result.failure(error)
        }
    }
}
