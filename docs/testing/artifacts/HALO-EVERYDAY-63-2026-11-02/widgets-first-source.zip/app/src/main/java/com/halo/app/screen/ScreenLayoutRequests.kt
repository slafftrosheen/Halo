package com.halo.app.screen

/** Bounded local commands. Unknown requests remain unsupported, never guessed or executed. */
internal object ScreenLayoutRequests {
    data class Plan(val changes: List<LayoutChange>, val researchQuery: String? = null)
    private val cardAliases = mapOf(
        "clock" to listOf("clock", "time", "date"),
        "weather" to listOf("weather", "forecast", "laikapstākļi", "laika apstākļi", "погода", "прогноз", "pogoda", "prognoza"),
        "calendar" to listOf("calendar", "календари", "календарь", "kalendārs", "kalendarz"),
        "tasks" to listOf("tasks", "task list", "to do", "to-do", "todos", "darbi", "uzdevumi", "задачи", "zadania"),
        "notebook" to listOf("notebook", "notes", "saved work", "piezīmes", "klade", "блокнот", "заметки", "notatki"),
        "study" to listOf("study", "learning", "mācības", "учёба", "учеба", "nauka"),
        "automation_result" to listOf("routine results", "automation results", "routine", "automātika", "процедуры", "rutyny"),
        "follow_up" to listOf("follow-ups", "follow ups", "follow up", "atgādinājumi", "напоминания", "przypomnienia"),
        "halo_activity" to listOf("halo activity", "what halo did", "activity"),
        "interests" to listOf("reading", "interests", "intereses", "интересы", "zainteresowania"),
        "device" to listOf("phone status", "this phone", "battery", "tālruņa stāvoklis", "akumulators", "состояние телефона", "батарея"),
    )

    fun propose(text: String, names: Map<String, String>): LayoutChange? {
        val request = text.trim().trimEnd('.', '!', '?').lowercase()
        val commands = listOf(
            listOf("add", "добавь", "добавить", "pievieno", "pievienot", "dodaj") to "add",
            listOf("hide", "remove", "скрой", "убери", "paslēp", "noņemt", "ukryj", "usuń") to "hide",
            listOf("enlarge", "увеличь", "palielini", "powiększ", "zwiększ") to "large",
            listOf("move to top", "в начало", "pārvieto augšā", "przenieś na górę", "przesuń na górę") to "top",
        )
        for ((verbs, command) in commands) for (verb in verbs) {
            if (!request.startsWith("$verb ")) continue
            val noun = request.removePrefix("$verb ").trim()
            val type = names.entries.singleOrNull { (_, label) -> label.lowercase() == noun }?.key ?: return null
            if (type !in ScreenWidgets.types) return null
            return when (command) {
                "add" -> LayoutChange.Add(type, emptyMap())
                "hide" -> LayoutChange.Remove(type)
                "large" -> LayoutChange.Resize(type, CardSize.EXPANDED)
                else -> LayoutChange.Move(type, 0)
            }
        }
        return null
    }

    /**
     * Parses a bounded multi-card composition request. It only adds registered native cards;
     * a research topic is handed to the existing grounded-search flow, never answered here.
     */
    fun compose(text: String, names: Map<String, String>): Plan? {
        propose(text, names)?.let { return Plan(listOf(it)) }
        val normalized = normalize(text)
        val prefixes = listOf(
            "build my screen with", "build screen with", "create my screen with", "create screen with",
            "make my screen with", "make screen with", "добавь на экран", "собери экран с",
            "создай экран с", "izveido ekrānu ar", "pievieno ekrānam", "izveido manu ekrānu ar",
            "zbuduj ekran z", "dodaj na ekran",
        )
        val prefix = prefixes.firstOrNull { normalized.startsWith("$it ") } ?: return null
        val body = normalized.removePrefix(prefix).trim()
        if (body.isBlank()) return null

        val researchTerms = listOf(
            "research articles", "research", "articles", "pētījumi", "pētniecība", "raksti",
            "исследования", "исследование", "статьи", "badania", "artykuły", "artykuly",
        )
        val hasResearch = researchTerms.any { containsPhrase(body, it) }
        val recognized = names.entries.flatMap { (type, label) ->
            listOf(normalize(label)) + cardAliases[type].orEmpty()
        }.filter { phrase -> phrase.isNotBlank() && containsPhrase(body, phrase) }
            .flatMap { phrase -> names.entries.filter { (type, label) ->
                normalize(label) == phrase || phrase in cardAliases[type].orEmpty()
            }.map { it.key } }.toMutableSet()
        if (hasResearch) recognized += "research"
        if (recognized.isEmpty()) return null

        val additions = recognized.sortedBy { type ->
            (listOfNotNull(names[type]?.let(::normalize)) + cardAliases[type].orEmpty())
                .map { body.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: Int.MAX_VALUE
        }.map { type ->
            if (type !in ScreenWidgets.types) return null
            LayoutChange.Add(type, emptyMap())
        }
        val query = if (hasResearch) extractResearchQuery(body, names, researchTerms) else null
        return Plan(additions, query)
    }

    fun select(plan: Plan, indices: Set<Int>, research: Boolean): Plan = Plan(
        plan.changes.filterIndexed { index, _ -> index in indices }, plan.researchQuery.takeIf { research })

    fun apply(layout: ScreenLayout, plan: Plan): ScreenLayout? {
        if (plan.changes.size > 24) return null
        return plan.changes.fold(layout) { current, change ->
            if(change is LayoutChange.Add && current.cards.any { it.widgetType==change.widgetType && (change.config.isEmpty() || it.config==change.config) }) return@fold current
            apply(current, change) ?: if (change is LayoutChange.Add && current.cards.any { it.widgetType == change.widgetType }) current else return null
        }.takeIf { it.cards != layout.cards || !plan.researchQuery.isNullOrBlank() }
    }

    private fun extractResearchQuery(body: String, names: Map<String, String>, researchTerms: List<String>): String? {
        var query = body
        (names.values.map(::normalize) + researchTerms + cardAliases.values.flatten())
            .distinct().sortedByDescending { it.length }.forEach { phrase ->
            if (phrase.isNotBlank()) query = replacePhrase(query, phrase, " ")
        }
        val ignored = setOf(
            "and", "with", "about", "for", "my", "the", "a", "an", "screen", "build", "create", "make", "please",
            "с", "и", "на", "про", "экран", "экрану", "пожалуйста", "добавь", "собери", "создай",
            "un", "ar", "par", "lūdzu", "ekrānu", "ekrānam", "izveido", "pievieno",
            "i", "z", "na", "proszę", "ekran", "zbuduj", "dodaj",
        )
        val tokens = query.split(Regex("\\s+")).map { it.trim(',', '.', ';', ':', '!', '?', '"', '\'', '(', ')') }
            .filter { it.length > 1 && it !in ignored }
        return tokens.joinToString(" ").take(200).takeIf { it.isNotBlank() }
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('&', ' ')
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()

    private fun containsPhrase(text: String, phrase: String): Boolean =
        Regex("(?<![\\p{L}\\p{N}])${Regex.escape(phrase)}(?![\\p{L}\\p{N}])").containsMatchIn(text)

    private fun replacePhrase(text: String, phrase: String, replacement: String): String =
        Regex("(?<![\\p{L}\\p{N}])${Regex.escape(phrase)}(?![\\p{L}\\p{N}])").replace(text, replacement)

    fun apply(layout: ScreenLayout, change: LayoutChange): ScreenLayout? {
        val cards = layout.cards.toMutableList()
        when (change) {
            is LayoutChange.Add -> {
                if (change.widgetType !in ScreenWidgets.types || cards.size >= 24) return null
                com.halo.app.everyday.presentation.EverydayCards.screenKinds[change.widgetType]?.let {
                    require(com.halo.app.everyday.presentation.EverydayCardConfig.from(change.config,it).kind==it)
                }
                val seed=ScreenLayoutCodec.encode(layout)+"\u0000"+change.widgetType+"\u0000"+change.config.toSortedMap().entries.joinToString("") { "${it.key.length}:${it.key}${it.value.length}:${it.value}" }
                cards.add(ScreenCard(change.widgetType, null, CardSize.STANDARD, false, config = change.config,
                    presentationId=java.util.UUID.nameUUIDFromBytes(seed.toByteArray(Charsets.UTF_8)).toString()))
            }
            is LayoutChange.Remove -> {
                val matches=cards.withIndex().filter { it.value.widgetType==change.widgetType && (change.cardId==null || it.value.presentationId==change.cardId) }
                if (matches.size != 1) return null
                cards.removeAt(matches.single().index)
            }
            is LayoutChange.Resize -> {
                val matches=cards.indices.filter { cards[it].widgetType==change.widgetType && (change.cardId==null || cards[it].presentationId==change.cardId) }
                if (matches.size != 1) return null
                val index=matches.single()
                if (index < 0) return null
                val resized = cards[index].copy(size = change.size, placement = cards[index].placement?.let {
                    it.copy(width = if (change.size == CardSize.COMPACT) 6 else 12,
                        height = if (change.size == CardSize.EXPANDED) 2 else 1).bounded()
                })
                if (resized == cards[index]) return null
                cards[index] = resized
            }
            is LayoutChange.Move -> {
                val matches=cards.indices.filter { cards[it].widgetType==change.widgetType && (change.cardId==null || cards[it].presentationId==change.cardId) }
                if (matches.size != 1) return null
                val index=matches.single()
                if (index < 0 || change.toIndex !in cards.indices || index == change.toIndex) return null
                return layout.copy(cards = ScreenGrid.reorder(cards, index, change.toIndex))
            }
        }
        return layout.copy(cards = cards)
    }
}
