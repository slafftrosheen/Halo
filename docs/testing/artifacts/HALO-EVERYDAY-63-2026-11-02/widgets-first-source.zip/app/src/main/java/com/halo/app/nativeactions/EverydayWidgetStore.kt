package com.halo.app.nativeactions

import android.content.Context
import com.halo.app.everyday.presentation.*
import org.json.JSONObject

data class EverydayWidgetInstance(val id: Int, val version: Long, val config: EverydayCardConfig)

internal object EverydayWidgetGeneration {
    private val value=java.util.concurrent.atomic.AtomicLong()
    fun current()=value.get()
    fun invalidate(): Long = value.incrementAndGet()
}
internal class WidgetPublicationChanged : IllegalStateException()

internal object EverydayWidgetReview {
    fun encode(value: EverydayWidgetInstance): String = JSONObject().put("id",value.id).put("version",value.version)
        .put("config",JSONObject(value.config.fields())).toString()
    fun restore(raw: String): EverydayWidgetInstance {
        require(raw.length<=8192)
        val json=JSONObject(raw);val fields=json.getJSONObject("config")
        val id=json.getInt("id");val version=json.getLong("version");require(id>0 && version>=0)
        return EverydayWidgetInstance(id,version,EverydayCardConfig.from(fields.keys().asSequence().associateWith { fields.getString(it) },EverydayCardKind.CLOCK))
    }
}

/** Independent durable instances. Reconfiguration uses CAS and cancellation never writes a draft. */
class EverydayWidgetStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences("halo_everyday_widgets_v1", Context.MODE_PRIVATE)
    fun get(id: Int): EverydayWidgetInstance? = synchronized(lock) {
        if (id <= 0) return@synchronized null
        runCatching {
            val raw = preferences.getString("widget:$id", null) ?: return@synchronized null
            val json = JSONObject(raw); val fields = json.getJSONObject("config")
            EverydayWidgetInstance(id, json.getLong("version"), EverydayCardConfig.from(fields.keys().asSequence().associateWith { fields.getString(it) }, EverydayCardKind.CLOCK))
        }.getOrNull()
    }
    fun save(id: Int, expectedVersion: Long?, config: EverydayCardConfig, allowed: () -> Unit = {}): EverydayWidgetInstance = synchronized(lock) {
        require(id > 0 && config.hidePrivate && config.limit<=3 && config.sections.size<=3); allowed()
        val current = get(id)
        check(current?.version == expectedVersion) { "Widget configuration changed" }
        val next = EverydayWidgetInstance(id, (current?.version ?: 0) + 1, config)
        allowed()
        EverydayWidgetGeneration.invalidate()
        check(preferences.edit().putString("widget:$id", JSONObject().put("version", next.version)
            .put("config", JSONObject(config.fields())).toString()).commit()) { "Could not save widget settings" }
        next
    }
    fun remove(id: Int) = synchronized(lock) { EverydayWidgetGeneration.invalidate();check(preferences.edit().remove("widget:$id").commit()) }
    internal fun publishIfCurrent(instance: EverydayWidgetInstance, generation: Long, publish: () -> Unit) = synchronized(lock) {
        if((get(instance.id)?.version ?: 0)!=instance.version || generation!=EverydayWidgetGeneration.current()) throw WidgetPublicationChanged()
        publish()
    }
    fun restored(oldId: Int, newId: Int) = synchronized(lock) {
        get(oldId)?.let { old -> if (get(newId) == null) save(newId, null, old.config) }
        if (oldId != newId) remove(oldId)
    }
    companion object { private val lock = Any() }
}
