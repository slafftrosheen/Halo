package com.halo.app.data.agent

import androidx.room.withTransaction
import com.halo.app.data.AppDatabase
import com.halo.cognition.language.InteractionId
import com.halo.runtime.cognition.agent.*
import com.halo.runtime.cognition.tools.ToolId
import com.halo.sdk.host.ObservationSource
import com.halo.sdk.runtime.AudioDeviceKind
import com.halo.sdk.runtime.ObservationOrigin
import com.halo.sdk.runtime.SpeechOutputTarget
import com.halo.sdk.runtime.SpeechOutputFallback
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

/**
 * RUNTIME-018: Room adapter for the durable execution journal.
 *
 * New journal step types use step schemaVersion 5. Historical versions (<=4)
 * decode unchanged; unknown newer versions decode as conservative legacy
 * evidence without inventing fields. `ToolDispatched` decodes as the legacy
 * claim it always was.
 */
class RoomAgentRunRepository(private val db: AppDatabase) : AgentRunStore {
    private val dao get() = db.agentRunDao()
    override fun observeRuns() = dao.observeRuns().map { rows -> rows.map { it.toDomain() } }
    override suspend fun get(runId: AgentRunId) = dao.get(runId.value)?.toDomain()
    override suspend fun children(parent: AgentRunId) = dao.children(parent.value).map { it.toDomain() }
    override suspend fun createChildIfAllowed(parent: AgentRunId, child: AgentRun, maxChildren: Int): Boolean = db.withTransaction {
        val root = get(parent) ?: return@withTransaction false
        if (root.state.isTerminal || root.delegationDepth != 0 || child.parentRunId != parent || child.delegationDepth != 1 ||
            get(child.id) != null || children(parent).size >= maxChildren.coerceIn(1, 4)) return@withTransaction false
        create(child)
        true
    }
    override suspend fun nonTerminalRuns() = dao.nonTerminalRuns().map { it.toDomain() }
    @Deprecated("Returns every non-terminal run; renamed for honesty")
    override suspend fun interruptedRuns() = nonTerminalRuns()

    override suspend fun claimResume(runId: AgentRunId, expectedState: AgentRunState): Boolean =
        dao.claimResume(runId.value, expectedState.name, System.currentTimeMillis()) == 1

    override suspend fun claimRecovery(
        runId: AgentRunId,
        expectedState: AgentRunState,
        claim: AgentStep.RecoveryClaimed,
    ): Boolean = db.withTransaction {
        if (dao.claimResume(runId.value, expectedState.name, System.currentTimeMillis()) != 1) {
            return@withTransaction false
        }
        check(appendStep(claim)) { "Recovery claim fingerprint already exists" }
        true
    }

    /**
     * RUNTIME-019: atomic first-wins input resolution. A single Room
     * transaction re-checks that the request is still pending (latest
     * InputRequested with no matching InputResolved) before appending the
     * resolution, so concurrent hosts can never double-resolve.
     */
    override suspend fun resolveInputIfPending(
        requestId: AgentInputRequestId,
        resolution: AgentInputResolution,
    ): Boolean = db.withTransaction {
        val runId = dao.latestInputRequestedRunId("%\"requestId\":\"${requestId.value}\"%")
            ?: return@withTransaction false
        val row = dao.get(runId) ?: return@withTransaction false
        val run = row.toDomain()
        if (run.state.isTerminal) return@withTransaction false
        val pending = run.steps.fold(mutableSetOf<String>()) { acc, step ->
            when (step) {
                is AgentStep.InputRequested -> if (step.requestId == requestId) acc.add(step.requestId.value)
                is AgentStep.InputResolved -> acc.remove(step.requestId.value)
                else -> Unit
            }
            acc
        }
        if (requestId.value !in pending) return@withTransaction false
        appendStep(
            AgentStep.InputResolved(
                AgentStepId(UUID.randomUUID().toString()), run.id, Instant.now(),
                requestId, AgentInputResolutions.encode(resolution),
            )
        )
        true
    }

    override suspend fun create(run: AgentRun) = db.withTransaction {
        dao.insertRun(run.toEntity())
        val metadata = JSONObject().put("createdAt", run.createdAt.toEpochMilli())
            .put("originSource", run.origin?.source?.javaClass?.simpleName)
            .put("originHost", run.origin?.hostId)
            .put("outputDevice", (run.speechOutputTarget as? SpeechOutputTarget.Device)?.deviceId)
            .put("outputKind", (run.speechOutputTarget as? SpeechOutputTarget.Device)?.kind?.name)
            .put("outputName", (run.speechOutputTarget as? SpeechOutputTarget.Device)?.displayName)
            .put("hostDefaultOutput", run.speechOutputTarget == SpeechOutputTarget.HostDefault)
            .put("phoneOutput", run.speechOutputTarget == SpeechOutputTarget.Phone)
            .put("fallback", run.speechOutputFallback.name)
            .put("sourceCaptureId", run.sourceCaptureId)
        dao.insertStep(AgentStepEntity("${run.id.value}:metadata", run.id.value, run.interactionId.value,
            0, "RunMetadata", 3, metadata.toString(), null, "RECORDED", run.createdAt.toEpochMilli(), null))
        run.steps.forEach { appendStep(it) }
    }
    override suspend fun update(run: AgentRun) {
        check(dao.updateRun(run.toEntity()) == 1) { "Run does not exist" }
    }
    override suspend fun appendStep(step: AgentStep): Boolean = db.withTransaction {
        val row = requireNotNull(dao.get(step.runId.value)) { "Run does not exist" }
        check(!row.toDomain().state.isTerminal) { "Run is terminal" }
        val (payload, type) = payloadFor(step)
        val key = when (step) {
            is AgentStep.ToolDispatched -> step.idempotencyKey
            is AgentStep.ToolExecutionClaimed -> step.idempotencyKey
            is AgentStep.ToolInvocationPrepared -> step.idempotencyKey
            else -> null
        }
        if (row.steps.any { it.id == step.id.value } ||
            (key != null && dao.countIdempotencyKeyForType(key, type) > 0)
        ) {
            return@withTransaction false
        }
        val truth = when (step) {
            is AgentStep.ToolDispatched -> ActionTruth.DISPATCHED
            is AgentStep.ToolExecutionClaimed -> ActionTruth.AUTHORIZED
            is AgentStep.ToolOutcomeRecorded -> step.actionTruth
            is AgentStep.ToolCompleted -> step.actionTruth
            is AgentStep.ToolFailed, is AgentStep.ToolRejected -> ActionTruth.FAILED
            else -> ActionTruth.PROPOSED
        }
        val completedAt = step.createdAt.toEpochMilli().takeIf {
            step is AgentStep.ToolCompleted || step is AgentStep.ToolFailed || step is AgentStep.ToolRejected ||
                step is AgentStep.ToolOutcomeRecorded || step is AgentStep.ResponseProduced ||
                step is AgentStep.ProviderTurnCompleted || step is AgentStep.ResponseCommitted ||
                step is AgentStep.DirectCommandAuthorityRecorded || step is AgentStep.ExternalConditionRegistered ||
                step is AgentStep.ExternalConditionSatisfied || step is AgentStep.ExternalConditionExpired ||
                step is AgentStep.ExternalConditionCancelled
        }
        dao.insertStep(AgentStepEntity(step.id.value, step.runId.value, row.run.interactionId,
            (row.steps.maxOfOrNull { it.ordinal } ?: -1) + 1, type, STEP_SCHEMA_VERSION, payload.toString(), key,
            truth.name, step.createdAt.toEpochMilli(), completedAt))
        dao.updateRun(row.run.copy(updatedAt = maxOf(row.run.updatedAt, step.createdAt.toEpochMilli())))
        true
    }

    private fun payloadFor(step: AgentStep): Pair<JSONObject, String> {
        val payload = JSONObject()
        val type = when (step) {
            is AgentStep.SemanticAppOperationRecorded -> {
                payload.put("semantic", SemanticOperationCodec.encode(step.receipt, step.argumentShapes))
                "SemanticAppOperationRecorded"
            }
            is AgentStep.UiTransactionRecorded -> {
                payload.put("transaction", UiTransactionCodec.encode(step.transaction))
                "UiTransactionRecorded"
            }
            is AgentStep.DelegationResultRecorded -> {
                payload.put("status", step.status).put("summary", step.summary).put("payloadRefId", step.payloadRefId)
                    .put("evidence", org.json.JSONArray(step.evidence.map { value -> JSONObject()
                        .put("sourceType", value.sourceType).put("sourceRef", value.sourceRef).put("title", value.title)
                        .put("retrievedAtMs", value.retrievedAtMs).put("payloadRefId", value.payloadRefId).put("sha256", value.sha256)
                        .put("excerpt", value.excerpt).put("revision", value.revision) }))
                "DelegationResultRecorded"
            }
            is AgentStep.ContextUsed -> {
                payload.put("objectIds", org.json.JSONArray(step.objectIds)).put("memoryIds", org.json.JSONArray(step.memoryIds))
                    .put("workspaceReferences", org.json.JSONArray(step.workspaceReferences.map { reference ->
                        JSONObject().put("objectId", reference.objectId).put("version", reference.version ?: JSONObject.NULL)
                            .put("textAnchor", reference.textAnchor?.let { anchor -> JSONObject().put("blockId", anchor.blockId)
                                .put("start", anchor.start).put("end", anchor.end) } ?: JSONObject.NULL)
                    }))
                "ContextUsed"
            }
            is AgentStep.PlanCreated -> { payload.put("planId", step.planId).put("summary", step.summary); "PlanCreated" }
            is AgentStep.ClarificationRequested -> { payload.put("question", step.question).put("field", step.field); "ClarificationRequested" }
            is AgentStep.ApprovalRequested -> { payload.put("action", step.action).put("risk", step.risk); "ApprovalRequested" }
            is AgentStep.ToolRequested -> { payload.put("toolCallId", step.toolCallId).put("toolId", step.toolId).put("argumentsJson", step.argumentsJson); "ToolRequested" }
            is AgentStep.ToolDispatched -> { payload.put("toolCallId", step.toolCallId).put("toolId", step.toolId); "ToolDispatched" }
            is AgentStep.ToolCompleted -> { payload.put("toolCallId", step.toolCallId).put("toolId", step.toolId).put("resultSummary", step.resultSummary).put("success", step.success).put("actionTruth", step.actionTruth.name); "ToolCompleted" }
            is AgentStep.ToolFailed -> { payload.put("toolCallId", step.toolCallId).put("toolId", step.toolId).put("reason", step.reason); "ToolFailed" }
            is AgentStep.ToolRejected -> { payload.put("toolCallId", step.toolCallId).put("toolId", step.toolId).put("reasonCode", step.reasonCode.name).put("reason", step.reason).put("retryable", step.retryable).put("requiresUserAction", step.requiresUserAction).put("modelResult", step.modelResult); "ToolRejected" }
            is AgentStep.ResponseProduced -> { payload.put("responseId", step.responseId).put("text", step.text).put("payloadRefId", step.payloadRefId); "ResponseProduced" }

            is AgentStep.RunPrepared -> { payload.put("kind", step.kind.name).put("recoveryPolicy", step.recoveryPolicy.name)
                .put("conversationId", step.conversationId).put("responseDelivery", step.responseDelivery?.name)
                .put("inputModality", step.inputModality?.name).put("inputRoute", step.inputRoute?.let(::encodeInputRoute)); "RunPrepared" }
            is AgentStep.ContinuityBound -> { payload.put("conversationId", step.conversationId); "ContinuityBound" }
            is AgentStep.InteractionHandoffRecorded -> { payload.put("from", encodeEndpoint(step.from)).put("to", encodeEndpoint(step.to))
                .put("reason", step.reason.name).put("channel", step.channel.name); "InteractionHandoffRecorded" }
            is AgentStep.ProviderTurnStarted -> {
                payload.put("turnId", step.turnId.value).put("providerId", step.providerId)
                    .put("modelId", step.modelId ?: "").put("requestIdentity", step.requestIdentity)
                    .put("exposedToolIds", JSONArray(step.exposedToolIds.toList()))
                    .put("requiredCapabilities", JSONArray(step.requiredCapabilities.toList()))
                    .put("contextRequirements", JSONArray(step.contextRequirements.toList()))
                    .put("toolUseMode", step.toolUseMode ?: "").put("workloadKind", step.workloadKind ?: "")
                "ProviderTurnStarted"
            }
            is AgentStep.ProviderTurnCompleted -> {
                val calls = JSONArray()
                step.toolCalls.forEach { call ->
                    calls.put(JSONObject().put("toolCallId", call.toolCallId)
                        .put("toolName", call.toolName).put("argumentsJson", call.argumentsJson))
                }
                payload.put("turnId", step.turnId.value).put("assistantText", step.assistantText)
                    .put("toolCalls", calls).put("finishReason", step.finishReason).put("payloadRefId", step.payloadRefId)
                "ProviderTurnCompleted"
            }
            is AgentStep.ToolInvocationPrepared -> {
                payload.put("invocationId", step.invocationId.value).put("toolCallId", step.toolCallId)
                    .put("toolId", step.toolId).put("argumentsJson", step.argumentsJson)
                    .put("argumentsDigest", step.argumentsDigest).put("idempotencyKey", step.idempotencyKey)
                    .put("descriptorVersion", step.descriptorVersion).put("replaySafety", step.replaySafety)
                step.remoteDataCategories?.let { payload.put("remoteDataCategories", JSONArray(it.toList())) }
                step.remoteDispatchRevision?.let { payload.put("remoteDispatchRevision", it) }
                "ToolInvocationPrepared"
            }
            is AgentStep.ToolExecutionClaimed -> {
                payload.put("invocationId", step.invocationId.value).put("toolCallId", step.toolCallId)
                    .put("toolId", step.toolId).put("idempotencyKey", step.idempotencyKey)
                    .put("replaySafety", step.replaySafety)
                "ToolExecutionClaimed"
            }
            is AgentStep.ResourceBlocked -> {
                val rIds = JSONArray().apply { step.resourceIds.forEach { put(it) } }
                val eIds = JSONArray().apply { step.endpointIds.forEach { put(it) } }
                val bIds = JSONArray().apply { step.blockingLeaseIds.forEach { put(it) } }
                payload.put("invocationId", step.invocationId.value).put("toolId", step.toolId)
                    .put("resourceIds", rIds).put("endpointIds", eIds).put("blockingLeaseIds", bIds)
                "ResourceBlocked"
            }
            is AgentStep.ToolOutcomeRecorded -> {
                payload.put("invocationId", step.invocationId.value).put("toolCallId", step.toolCallId)
                    .put("toolId", step.toolId).put("success", step.success).put("output", step.output)
                    .put("actionTruth", step.actionTruth.name).put("failureKind", step.failureKind ?: "")
                    .put("payloadRefId", step.payloadRefId).put("payloadSha256", step.payloadSha256).put("payloadBytes", step.payloadBytes)
                "ToolOutcomeRecorded"
            }
            is AgentStep.InputRequested -> {
                val input = when (val req = step.input) {
                    is AgentInputRequest.Approval -> JSONObject().put("inputType", "APPROVAL")
                        .put("invocationId", req.invocationId.value).put("toolId", req.toolId.value)
                        .put("action", req.action).put("risk", req.risk)
                        .put("argumentsDigest", req.argumentsDigest)
                        .put("detail", req.detail ?: "")
                        .put("speechPrompt", req.speechPrompt ?: "")
                        .put("expiresAt", req.expiresAt?.toString() ?: "")
                    is AgentInputRequest.Clarification -> JSONObject().put("inputType", "CLARIFICATION")
                        .put("question", req.question).put("field", req.field)
                        .put("speechPrompt", req.speechPrompt ?: "")
                        .put("expiresAt", req.expiresAt?.toString() ?: "")
                        .put("expected", encodeExpected(req.expected))
                }
                payload.put("requestId", step.requestId.value).put("input", input)
                "InputRequested"
            }
            is AgentStep.InputResolved -> {
                payload.put("requestId", step.requestId.value).put("resolution", step.resolution)
                "InputResolved"
            }
            is AgentStep.ContinuationPrepared -> {
                payload.put("turnId", step.turnId.value).put("messageCount", step.messageCount)
                    .put("exposedToolIds", JSONArray(step.exposedToolIds.toList()))
                "ContinuationPrepared"
            }
            is AgentStep.ResponseCommitted -> {
                payload.put("commitId", step.commitId).put("interactionId", step.interactionId)
                "ResponseCommitted"
            }
            is AgentStep.RecoveryClaimed -> {
                payload.put("planKind", step.planKind).put("evidenceStepId", step.evidenceStepId ?: "")
                "RecoveryClaimed"
            }
            is AgentStep.RunGuardTriggered -> {
                payload.put("reason", step.reason.name).put("round", step.round)
                    .put("toolId", step.toolId ?: "")
                    .put("evidenceHash", step.evidenceHash ?: "")
                    .put("elapsedMs", step.elapsedMs)
                    .put("summary", step.summary)
                "RunGuardTriggered"
            }
            is AgentStep.DirectCommandAuthorityRecorded -> {
                payload.put("interactionId", step.authority.interactionId.value).put("toolId", step.authority.toolId)
                    .put("argumentsDigest", step.authority.argumentsDigest)
                    .put("originSource", step.authority.origin.source.name)
                val dId = step.authority.origin.sourceDeviceId
                payload.put("originHostId", dId ?: "")
                payload.put("issuedAtMs", step.authority.issuedAt.toEpochMilli())
                "DirectCommandAuthorityRecorded"
            }
            is AgentStep.ExternalConditionRegistered -> {
                payload.put("watchId", step.watchId).put("conditionType", step.conditionType)
                    .put("targetId", step.targetId ?: "").put("presentationText", step.presentationText ?: "")
                "ExternalConditionRegistered"
            }
            is AgentStep.ExternalConditionSatisfied -> {
                payload.put("watchId", step.watchId).put("conditionType", step.conditionType)
                    .put("targetId", step.targetId ?: "")
                "ExternalConditionSatisfied"
            }
            is AgentStep.ExternalConditionExpired -> {
                payload.put("watchId", step.watchId).put("conditionType", step.conditionType)
                "ExternalConditionExpired"
            }
            is AgentStep.ExternalConditionCancelled -> {
                payload.put("watchId", step.watchId).put("reason", step.reason ?: "")
                "ExternalConditionCancelled"
            }
        }
        return payload to type
    }

    private fun AgentRun.toEntity() = AgentRunEntity(id.value, interactionId.value, request,
        (startedAt ?: createdAt).toEpochMilli(), updatedAt.toEpochMilli(),
        completedAt?.toEpochMilli().takeIf { state.isTerminal }, state.name, failureReason,
        parentRunId?.value, rootRunId?.value, delegatedRole, delegationDepth, pinnedProviderId, pinnedModelId, pinnedTargetLocal, delegatedInputRefs)

    private fun AgentRunWithSteps.toDomain(): AgentRun {
        val ordered = steps.sortedWith(compareBy<AgentStepEntity> { it.ordinal }.thenBy { it.createdAt }.thenBy { it.id })
        val metadata = ordered.firstOrNull { it.type == "RunMetadata" }?.let { runCatching { JSONObject(it.payloadJson) }.getOrNull() }
        val source = when (metadata?.optString("originSource")) {
            "PhoneCamera" -> ObservationSource.PhoneCamera
            "AndroidPhoneMic" -> ObservationSource.AndroidPhoneMic
            "BluetoothHeadset" -> ObservationSource.BluetoothHeadset
            "AndroidAudioAccessory" -> ObservationSource.AndroidAudioAccessory
            "HeyCyanGlasses" -> ObservationSource.HeyCyanGlasses
            "Replay" -> ObservationSource.Replay
            "Debug" -> ObservationSource.Debug
            else -> null
        }
        val history = ordered.filterNot { it.type == "RunMetadata" }.map { entity ->
            runCatching { entity.toDomain() }.getOrElse {
                AgentStep.ToolFailed(AgentStepId(entity.id), AgentRunId(entity.runId), Instant.ofEpochMilli(entity.createdAt),
                    entity.id, "legacy", "Historical execution evidence could not be decoded")
            }
        }
        val unrecognized = history.filterIsInstance<AgentStep.ToolFailed>().any { it.toolId == "legacy" }
        val state = if (unrecognized) AgentRunState.INTERRUPTED else
            runCatching { AgentRunState.valueOf(run.state) }.getOrDefault(AgentRunState.INTERRUPTED)
        return AgentRun(AgentRunId(run.id), InteractionId(run.interactionId), run.request, state,
            source?.let { ObservationOrigin(it, metadata?.optString("originHost")?.takeIf(String::isNotBlank)) },
            Instant.ofEpochMilli(metadata?.optLong("createdAt", run.startedAt) ?: run.startedAt),
            Instant.ofEpochMilli(run.updatedAt), Instant.ofEpochMilli(run.startedAt),
            run.completedAt?.let(Instant::ofEpochMilli), history.lastOrNull()?.id, run.failureReason, history,
            metadata?.optString("outputDevice")?.takeIf(String::isNotBlank)?.let {
                SpeechOutputTarget.Device(it, null, metadata?.optString("outputName", "Wearable") ?: "Wearable", runCatching { AudioDeviceKind.valueOf(metadata?.optString("outputKind").orEmpty()) }.getOrDefault(AudioDeviceKind.WEARABLE))
            } ?: SpeechOutputTarget.HostDefault.takeIf { metadata?.optBoolean("hostDefaultOutput") == true } ?: SpeechOutputTarget.Phone.takeIf { metadata?.optBoolean("phoneOutput") == true },
            runCatching { SpeechOutputFallback.valueOf(metadata?.optString("fallback").orEmpty()) }.getOrDefault(SpeechOutputFallback.DISALLOW_PHONE),
            metadata?.optString("sourceCaptureId")?.takeIf(String::isNotBlank),
            parentRunId = run.parentRunId?.let(::AgentRunId), rootRunId = run.rootRunId?.let(::AgentRunId),
            delegatedRole = run.delegatedRole, delegationDepth = run.delegationDepth,
            pinnedProviderId = run.pinnedProviderId, pinnedModelId = run.pinnedModelId, pinnedTargetLocal = run.pinnedTargetLocal, delegatedInputRefs = run.delegatedInputRefs)
    }

    private fun AgentStepEntity.toDomain(): AgentStep {
        val p = JSONObject(payloadJson)
        val step = AgentStepId(id)
        val run = AgentRunId(runId)
        val at = Instant.ofEpochMilli(createdAt)
        val call = p.optString("toolCallId", id)
        val tool = p.optString("toolId", p.optString("toolName"))
        return when (type) {
            "SemanticAppOperationRecorded" -> SemanticOperationCodec.decode(p.getJSONObject("semantic")).let {
                AgentStep.SemanticAppOperationRecorded(step, run, at, it.first, it.second)
            }
            "UiTransactionRecorded" -> AgentStep.UiTransactionRecorded(step, run, at, UiTransactionCodec.decode(p.getJSONObject("transaction")))
            "DelegationResultRecorded" -> {
                val values = p.optJSONArray("evidence") ?: org.json.JSONArray()
                AgentStep.DelegationResultRecorded(step, run, at, p.getString("status"), p.getString("summary"),
                    (0 until values.length().coerceAtMost(16)).map { index -> val value = values.getJSONObject(index)
                        AgentEvidenceRecord(value.getString("sourceType"), value.getString("sourceRef"), value.getString("title"),
                            value.getLong("retrievedAtMs"), value.optString("payloadRefId").takeIf { it.isNotBlank() && it != "null" },
                            value.optString("sha256").takeIf { it.isNotBlank() && it != "null" }, value.optString("excerpt"),
                            value.optString("revision").takeIf { it.isNotBlank() && it != "null" }) },
                    p.optString("payloadRefId").takeIf { it.isNotBlank() && it != "null" })
            }
            "ContextUsed" -> {
                fun ids(key: String, limit: Int): List<String> { val array = p.optJSONArray(key) ?: org.json.JSONArray()
                    require(array.length() <= limit)
                    return (0 until array.length()).map { array.getString(it).also { value -> require(value.length in 1..240) } }
                }
                val references = p.optJSONArray("workspaceReferences") ?: org.json.JSONArray()
                require(references.length() <= 20)
                AgentStep.ContextUsed(step, run, at, ids("objectIds",20), ids("memoryIds",12),
                    (0 until references.length()).map { index ->
                        val reference = references.getJSONObject(index)
                        val objectId = reference.getString("objectId").also { require(it.length in 1..240) }
                        val version = if (reference.isNull("version")) null else reference.getString("version")
                        val anchor = reference.optJSONObject("textAnchor")?.let {
                            com.halo.sdk.runtime.study.StudyTextAnchor(it.getString("blockId"), it.getInt("start"), it.getInt("end"))
                        }
                        com.halo.runtime.cognition.context.ContextReference.WorkspaceObject(objectId, version, anchor)
                    })
            }
            "PlanCreated" -> AgentStep.PlanCreated(step, run, at, p.getString("planId"), p.getString("summary"))
            "ClarificationRequested" -> AgentStep.ClarificationRequested(step, run, at, p.getString("question"), p.getString("field"))
            "ApprovalRequested" -> AgentStep.ApprovalRequested(step, run, at, p.getString("action"), p.getString("risk"))
            "ToolRequested" -> AgentStep.ToolRequested(step, run, at, call, tool, p.optString("argumentsJson", p.optJSONObject("args")?.toString() ?: "{}"))
            "ToolDispatched" -> AgentStep.ToolDispatched(step, run, at, call, tool, idempotencyKey)
            "ToolCompleted" -> AgentStep.ToolCompleted(step, run, at, call, tool, p.optString("resultSummary", p.optString("result")), p.getBoolean("success"), runCatching { ActionTruth.valueOf(p.optString("actionTruth", "UNKNOWN")) }.getOrDefault(ActionTruth.UNKNOWN))
            "ToolFailed" -> AgentStep.ToolFailed(step, run, at, call, tool, p.getString("reason"))
            "ResponseProduced" -> AgentStep.ResponseProduced(step, run, at, p.getString("responseId"), p.getString("text"), p.optString("payloadRefId").takeIf { it.isNotBlank() && it != "null" })

            "RunPrepared" -> AgentStep.RunPrepared(step, run, at,
                runCatching { AgentRunKind.valueOf(p.getString("kind")) }.getOrDefault(AgentRunKind.INTERACTIVE),
                runCatching { RunRecoveryPolicy.valueOf(p.getString("recoveryPolicy")) }.getOrDefault(RunRecoveryPolicy.USER_RESUME), p.optString("conversationId").takeIf { it.isNotBlank() && it != "null" },
                runCatching { com.halo.sdk.runtime.ResponseDelivery.valueOf(p.getString("responseDelivery")) }.getOrNull(),
                runCatching { com.halo.runtime.cognition.turn.InteractionInputModality.valueOf(p.getString("inputModality")) }.getOrNull(),
                p.optJSONObject("inputRoute")?.let(::decodeInputRoute))
            "ContinuityBound" -> AgentStep.ContinuityBound(step, run, at, p.getString("conversationId"))
            "InteractionHandoffRecorded" -> AgentStep.InteractionHandoffRecorded(step, run, at, decodeEndpoint(p.getJSONObject("from")),
                decodeEndpoint(p.getJSONObject("to")), com.halo.runtime.cognition.continuity.InteractionHandoffReason.valueOf(p.getString("reason")),
                com.halo.runtime.cognition.continuity.InteractionHandoffChannel.valueOf(p.optString("channel", "AUDIO_OUTPUT")))
            "ProviderTurnStarted" -> AgentStep.ProviderTurnStarted(step, run, at,
                ProviderTurnId(p.getString("turnId")), p.getString("providerId"), p.optString("modelId").ifBlank { null },
                p.optString("requestIdentity"), stringSet(p, "exposedToolIds"),
                stringSet(p, "requiredCapabilities"), stringSet(p, "contextRequirements"),
                p.optString("toolUseMode").ifBlank { null }, p.optString("workloadKind").ifBlank { null })
            "ProviderTurnCompleted" -> {
                val calls = mutableListOf<ProviderToolCallRecord>()
                val array = p.optJSONArray("toolCalls") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    calls += ProviderToolCallRecord(item.getString("toolCallId"), item.getString("toolName"),
                        item.optString("argumentsJson", "{}"))
                }
                AgentStep.ProviderTurnCompleted(step, run, at, ProviderTurnId(p.getString("turnId")),
                    p.optString("assistantText"), calls, p.optString("finishReason", "unknown"), p.optString("payloadRefId").takeIf { it.isNotBlank() && it != "null" })
            }
            "ToolInvocationPrepared" -> AgentStep.ToolInvocationPrepared(step, run, at,
                ToolInvocationId(p.getString("invocationId")), call, tool, p.optString("argumentsJson", "{}"),
                p.optString("argumentsDigest"), p.optString("idempotencyKey", id),
                p.optInt("descriptorVersion", 0), p.optString("replaySafety", "NEVER_REPLAY"),
                remoteDataCategories = p.optJSONArray("remoteDataCategories")?.let { array ->
                    require(array.length() <= com.halo.sdk.provider.RemoteDataCategory.entries.size)
                    (0 until array.length()).map { array.getString(it) }.toSet()
                },
                remoteDispatchRevision = if (p.has("remoteDispatchRevision") && !p.isNull("remoteDispatchRevision"))
                    p.getLong("remoteDispatchRevision") else null)
            "ToolExecutionClaimed" -> AgentStep.ToolExecutionClaimed(step, run, at,
                ToolInvocationId(p.getString("invocationId")), call, tool,
                p.optString("idempotencyKey", idempotencyKey ?: id), p.optString("replaySafety", "NEVER_REPLAY"))
            "ResourceBlocked" -> {
                val rArray = p.optJSONArray("resourceIds")
                val eArray = p.optJSONArray("endpointIds")
                val bArray = p.optJSONArray("blockingLeaseIds")
                val rList = buildList { if (rArray != null) for (i in 0 until rArray.length()) add(rArray.getString(i)) }
                val eList = buildList { if (eArray != null) for (i in 0 until eArray.length()) add(eArray.getString(i)) }
                val bList = buildList { if (bArray != null) for (i in 0 until bArray.length()) add(bArray.getString(i)) }
                AgentStep.ResourceBlocked(step, run, at, ToolInvocationId(p.optString("invocationId")), tool, rList, eList, bList)
            }
            "ToolOutcomeRecorded" -> AgentStep.ToolOutcomeRecorded(step, run, at,
                ToolInvocationId(p.getString("invocationId")), call, tool, p.getBoolean("success"),
                p.optString("output"), runCatching { ActionTruth.valueOf(p.getString("actionTruth")) }.getOrDefault(ActionTruth.UNKNOWN),
                p.optString("failureKind").ifBlank { null }, p.optString("payloadRefId").ifBlank { null },
                p.optString("payloadSha256").ifBlank { null }, p.optLong("payloadBytes").takeIf { p.has("payloadBytes") })
            "ToolRejected" -> AgentStep.ToolRejected(step, run, at, call, tool,
                runCatching { ToolRejectionCode.valueOf(p.optString("reasonCode")) }
                    .getOrDefault(ToolRejectionCode.AUTHORIZATION_DENIED),
                p.optString("reason"), p.optBoolean("retryable", false),
                p.optBoolean("requiresUserAction", false), p.optString("modelResult"))
            "InputRequested" -> {
                val input = p.getJSONObject("input")
                val requestId = AgentInputRequestId(p.getString("requestId"))
                val expiresAt = input.optString("expiresAt").takeIf(String::isNotBlank)
                    ?.let { runCatching { Instant.parse(it) }.getOrNull() }
                when (input.optString("inputType")) {
                    "APPROVAL" -> AgentStep.InputRequested(step, run, at, requestId, AgentInputRequest.Approval(
                        id = requestId, runId = run, createdAt = at, expiresAt = expiresAt,
                        invocationId = ToolInvocationId(input.getString("invocationId")),
                        toolId = ToolId(input.getString("toolId")),
                        action = input.getString("action"),
                        detail = input.optString("detail").ifBlank { null },
                        risk = input.optString("risk", "SENSITIVE"),
                        argumentsDigest = input.getString("argumentsDigest"),
                        speechPrompt = input.optString("speechPrompt").ifBlank { null }))
                    else -> AgentStep.InputRequested(step, run, at, requestId, AgentInputRequest.Clarification(
                        id = requestId, runId = run, createdAt = at, expiresAt = expiresAt,
                        question = input.optString("question"), field = input.optString("field"),
                        expected = decodeExpected(input.optJSONObject("expected")),
                        speechPrompt = input.optString("speechPrompt").ifBlank { null }))
                }
            }
            "InputResolved" -> AgentStep.InputResolved(step, run, at,
                AgentInputRequestId(p.getString("requestId")), p.getString("resolution"))
            "ContinuationPrepared" -> AgentStep.ContinuationPrepared(step, run, at,
                ProviderTurnId(p.getString("turnId")), p.optInt("messageCount"), stringSet(p, "exposedToolIds"))
            "ResponseCommitted" -> AgentStep.ResponseCommitted(step, run, at,
                p.getString("commitId"), p.getString("interactionId"))
            "RecoveryClaimed" -> AgentStep.RecoveryClaimed(
                step, run, at, p.optString("planKind"), p.optString("evidenceStepId").ifBlank { null })
            "RunGuardTriggered" -> AgentStep.RunGuardTriggered(step, run, at,
                runCatching { RunGuardReason.valueOf(p.optString("reason")) }
                    .getOrDefault(RunGuardReason.TOO_MANY_TOOL_ROUNDS),
                p.optInt("round"),
                p.optString("toolId").ifBlank { null },
                p.optString("evidenceHash").ifBlank { null },
                p.optLong("elapsedMs"),
                p.optString("summary"))
            "DirectCommandAuthorityRecorded" -> AgentStep.DirectCommandAuthorityRecorded(
                step, run, at,
                DirectUserCommandAuthority(
                    interactionId = InteractionId(p.getString("interactionId")),
                    toolId = p.getString("toolId"),
                    argumentsDigest = p.getString("argumentsDigest"),
                    origin = com.halo.runtime.cognition.blackboard.InteractionOrigin(
                        source = runCatching { com.halo.sdk.runtime.Source.valueOf(p.optString("originSource")) }
                            .getOrDefault(com.halo.sdk.runtime.Source.USER),
                        sourceDeviceId = p.optString("originHostId").ifBlank { null },
                    ),
                    issuedAt = Instant.ofEpochMilli(p.optLong("issuedAtMs", at.toEpochMilli())),
                ),
            )
            "ExternalConditionRegistered" -> AgentStep.ExternalConditionRegistered(
                step, run, at,
                watchId = p.getString("watchId"),
                conditionType = p.getString("conditionType"),
                targetId = p.optString("targetId").ifBlank { null },
                presentationText = p.optString("presentationText").ifBlank { null },
            )
            "ExternalConditionSatisfied" -> AgentStep.ExternalConditionSatisfied(
                step, run, at,
                watchId = p.getString("watchId"),
                conditionType = p.getString("conditionType"),
                targetId = p.optString("targetId").ifBlank { null },
            )
            "ExternalConditionExpired" -> AgentStep.ExternalConditionExpired(
                step, run, at,
                watchId = p.getString("watchId"),
                conditionType = p.getString("conditionType"),
            )
            "ExternalConditionCancelled" -> AgentStep.ExternalConditionCancelled(
                step, run, at,
                watchId = p.getString("watchId"),
                reason = p.optString("reason").ifBlank { null },
            )
            // Legacy reasoning is deliberately not exposed as public execution evidence.
            else -> AgentStep.ToolFailed(step, run, at, id, "legacy", "Unsupported historical step: $type")
        }
    }

    private fun encodeInputRoute(route: com.halo.sdk.runtime.SpeechInputRoute): JSONObject = when (route) {
        com.halo.sdk.runtime.SpeechInputRoute.Phone -> JSONObject().put("type", "PHONE")
        is com.halo.sdk.runtime.SpeechInputRoute.Device -> JSONObject().put("type", "DEVICE")
            .put("deviceId", route.deviceId).put("platformEndpointId", route.platformEndpointId)
            .put("displayName", route.displayName).put("kind", route.kind.name)
    }

    private fun decodeInputRoute(value: JSONObject): com.halo.sdk.runtime.SpeechInputRoute? = runCatching {
        when (value.getString("type")) {
            "PHONE" -> com.halo.sdk.runtime.SpeechInputRoute.Phone
            "DEVICE" -> com.halo.sdk.runtime.SpeechInputRoute.Device(
                value.optString("deviceId").takeIf { it.isNotBlank() && it != "null" },
                if (value.has("platformEndpointId") && !value.isNull("platformEndpointId")) value.getInt("platformEndpointId") else null,
                value.optString("displayName").takeIf { it.isNotBlank() && it != "null" },
                AudioDeviceKind.valueOf(value.getString("kind")))
            else -> null
        }
    }.getOrNull()

    private fun encodeExpected(expected: ExpectedInput): JSONObject {
        val obj = JSONObject()
        return when (expected) {
            is ExpectedInput.Confirmation -> obj.put("kind", "CONFIRMATION")
            is ExpectedInput.Text -> obj.put("kind", "TEXT")
                .put("placeholder", expected.placeholder ?: "")
                .put("minLength", expected.minLength).put("maxLength", expected.maxLength)
                .put("singleLine", expected.singleLine).put("sensitive", expected.sensitive)
            is ExpectedInput.Choice -> {
                obj.put("kind", "CHOICE").put("allowMultiple", expected.allowMultiple)
                val options = JSONArray()
                expected.options.forEach { option ->
                    options.put(JSONObject().put("id", option.id).put("label", option.label)
                        .put("description", option.description ?: ""))
                }
                obj.put("options", options)
            }
            is ExpectedInput.Temporal -> obj.put("kind", "TEMPORAL").put("mode", expected.mode.name)
            is ExpectedInput.Files -> {
                obj.put("kind", "FILES").put("allowMultiple", expected.allowMultiple)
                obj.put("acceptedKinds", JSONArray(expected.acceptedKinds.map { it.name }))
            }
        }
    }

    private fun decodeExpected(obj: JSONObject?): ExpectedInput {
        if (obj == null) return ExpectedInput.Text()
        return when (obj.optString("kind")) {
            "CONFIRMATION" -> ExpectedInput.Confirmation
            "CHOICE" -> {
                val options = mutableListOf<ExpectedChoice>()
                val array = obj.optJSONArray("options") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    options += ExpectedChoice(item.getString("id"), item.getString("label"),
                        item.optString("description").ifBlank { null })
                }
                ExpectedInput.Choice(options, obj.optBoolean("allowMultiple", false))
            }
            "TEMPORAL" -> ExpectedInput.Temporal(
                runCatching { TemporalInputMode.valueOf(obj.optString("mode", "DATE_TIME")) }
                    .getOrDefault(TemporalInputMode.DATE_TIME))
            "FILES" -> {
                val kinds = mutableListOf<FileKind>()
                val array = obj.optJSONArray("acceptedKinds") ?: JSONArray()
                for (i in 0 until array.length()) {
                    runCatching { FileKind.valueOf(array.getString(i)) }.getOrNull()?.let { kinds += it }
                }
                ExpectedInput.Files(if (kinds.isEmpty()) setOf(FileKind.ANY) else kinds.toSet(),
                    obj.optBoolean("allowMultiple", false))
            }
            // TEXT (and legacy missing expected): initial values are never persisted.
            else -> ExpectedInput.Text(
                placeholder = obj.optString("placeholder").ifBlank { null },
                initialValue = null,
                minLength = obj.optInt("minLength", 0),
                maxLength = obj.optInt("maxLength", 2000),
                singleLine = obj.optBoolean("singleLine", false),
                sensitive = obj.optBoolean("sensitive", false),
            )
        }
    }

    private fun stringSet(p: JSONObject, key: String): Set<String> {
        val array = p.optJSONArray(key) ?: return emptySet()
        return buildSet { for (i in 0 until array.length()) add(array.getString(i)) }
    }

    private companion object {
        const val STEP_SCHEMA_VERSION = 7
    }
}

internal fun encodeEndpoint(endpoint: com.halo.runtime.cognition.continuity.InteractionEndpoint): JSONObject = JSONObject().apply {
    when (endpoint) {
        com.halo.runtime.cognition.continuity.InteractionEndpoint.Phone -> put("kind", "PHONE")
        com.halo.runtime.cognition.continuity.InteractionEndpoint.AndroidAssistant -> put("kind", "ANDROID_ASSISTANT")
        is com.halo.runtime.cognition.continuity.InteractionEndpoint.AudioAccessory -> { put("kind", "AUDIO_ACCESSORY"); put("accessoryId", endpoint.accessoryId); put("displayName", endpoint.displayName); put("audioKind", endpoint.audioKind.name) }
        is com.halo.runtime.cognition.continuity.InteractionEndpoint.WearOs -> { put("kind", "WEAR_OS"); put("nodeId", endpoint.nodeId); put("displayName", endpoint.displayName) }
        is com.halo.runtime.cognition.continuity.InteractionEndpoint.ManagedDevice -> { put("kind", "MANAGED_DEVICE"); put("deviceId", endpoint.deviceId); put("displayName", endpoint.displayName) }
    }
}
internal fun decodeEndpoint(json: JSONObject): com.halo.runtime.cognition.continuity.InteractionEndpoint = when (json.getString("kind")) {
    "WEARABLE", "MANAGED_DEVICE" -> com.halo.runtime.cognition.continuity.InteractionEndpoint.ManagedDevice(json.getString("deviceId"), json.optString("displayName").takeIf { it.isNotBlank() && it != "null" })
    "AUDIO_ACCESSORY" -> com.halo.runtime.cognition.continuity.InteractionEndpoint.AudioAccessory(json.getString("accessoryId"), json.optString("displayName").takeIf { it.isNotBlank() && it != "null" }, com.halo.sdk.runtime.AudioDeviceKind.valueOf(json.getString("audioKind")))
    "WEAR_OS" -> com.halo.runtime.cognition.continuity.InteractionEndpoint.WearOs(json.getString("nodeId"), json.optString("displayName").takeIf { it.isNotBlank() && it != "null" })
    "ANDROID_ASSISTANT" -> com.halo.runtime.cognition.continuity.InteractionEndpoint.AndroidAssistant
    else -> com.halo.runtime.cognition.continuity.InteractionEndpoint.Phone
}
