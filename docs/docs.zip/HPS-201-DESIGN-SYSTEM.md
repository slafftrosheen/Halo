# HPS-201: Halo Design System

## Philosophy
Not Material. Not iOS. Not Windows. Halo.
Three words: **Calm. Trustworthy. Precise.**

## Visual Identity
The interface should feel like professional equipment (Sony Alpha Camera, DJI RC Controller, Ableton Live). Never playful.

## Color Language
Semantic colors based on "Olive Spruce". No blue, no purple, no gradients, very little saturation.

* **Canvas**: `#10130F`
* **Surface**: `#181D17`
* **Surface Elevated**: `#232A20`
* **Accent (Olive Spruce)**: `#4A5F3C`
* **Success**: `#6D8C52`
* **Warning (Terracotta)**: `#E2725B`
* **Muted**: `#8A9386`
* **Text**: `#F5F5F2`

## Typography
One font. Inter, SF Pro, or IBM Plex Sans.
Mono: JetBrains Mono.

## Spacing Scale
`2, 4, 8, 12, 16, 24, 32, 48, 64`. No magic numbers.

## Radius
`4, 8, 12`. Never arbitrary.

## Motion
Maximum duration: 300ms.
* **Immediate**: 120ms
* **Navigation**: 180ms
* **Large**: 250ms
