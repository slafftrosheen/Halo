# HPS-202: Component Specification

Instead of dozens of random components, create primitives and compose everything else.

## Primitive Components
`Text`, `Icon`, `Divider`, `Badge`, `Chip`, `Button`, `Toggle`, `Progress`, `Avatar`.

## Layout Components
`Column`, `Row`, `Stack`, `Flow`, `Card`, `Section`, `Sheet`, `Dialog`.

## Halo Components

* **StateTile**: Display operational status (Connected, Listening, Thinking).
* **MetricRow**: One row with a label and metric (e.g., Latency: 148ms).
* **TrustBadge**: Instant trust indication (LOCAL, CLOUD, USER, VERIFIED).
* **ProviderCard**: Provider capabilities.
* **CapabilityChip**: Small capability tag (Vision, BLE, Speech).
* **WorkflowCard**: IF/THEN automation display.
* **TimelineItem**: History entry.
* **RuntimeCard**: Engine health.
* **HealthIndicator**: Simple operational status (`██████████ Healthy`).
